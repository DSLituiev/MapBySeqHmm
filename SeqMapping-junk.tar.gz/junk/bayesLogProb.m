function  ValidChrReads = bayesLogProb(ValidChrReads)
% adds and normalizes (prior* likelihood)/sum
%
% ====== Input fields  ======
%
% .logPobsN -- observed likelihood
% .logPrior -- prior probability
%
% ====== Output fields ======
% 
% .logPost   -- posterior probability

for chr = 1:length(ValidChrReads)
    ValidChrReads(chr).logPost = ValidChrReads(chr).logPobsN + ValidChrReads(chr).logPrior;
    Beta = - median(ValidChrReads(chr).logPost);
    logSumP = - Beta + log10( sum(10.^(Beta + ValidChrReads(chr).logPost) )); 
    ValidChrReads(chr).logPost = ValidChrReads(chr).logPost - logSumP;
end

