function [Coverage, xx, varargout] = CoverageAnalysis(ChrReads,ChrNumber,sigma)
%

xx = cell(ChrNumber,1);
Coverage = cell(ChrNumber,1);

if nargout>2
    medianCov = cell(ChrNumber,1);
    histLogCov =  cell(ChrNumber,1);
end

% sigma = 1e5;
for chr = 1:ChrNumber
r = single(ChrReads(chr).r);
x = double(ChrReads(chr).x);
W = exp( - 0.5*(bsxfun(@minus,x,x')./sigma).^2);
Coverage{chr,1} = W*r;
xx(chr,1) = {ChrReads(chr).x};
if nargout>2
    medianCov{chr} = 10^(trapz(single(xx{chr}),log10(Coverage{chr,1}))./single(max(xx{chr}) - min(xx{chr})));
    %10^median(log10(Coverage{chr,1}));
    histLogCov{chr} = hist(log10(Coverage{chr,1}),(0:0.5:6.5));
end
end
if nargout>2
varargout = {medianCov; histLogCov};
end
% plot(single(Data_xrqExNsSt{1,chr}(:,1))*1e-6, single(Data_xrqExNsSt{1,chr}(:,3))./single(Data_xrqExNsSt{1,chr}(:,2)))
% scatter(xMb, ratio,4, log10(single(Data_xrqExNsSt{1,chr}(:,2))))
