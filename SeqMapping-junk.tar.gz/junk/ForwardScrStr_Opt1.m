% Main script
%==== Do coverage penalty after the filtering
%==== Analyse diff(x)! -- should be Poisson

close all; clear all; clc;
dbclear if warning
tic
addpath('D:\MATLABuserfunctions\mtimesx');
addpath('D:\MATLABuserfunctions\MinMaxSelection');
addpath('D:\MATLABuserfunctions'); savepath;
addpath('.\utilites');

%=       provide the reference ID, which is the name of the csv file without '.csv'
%= together with the backround genotype ID
%= known positions of the causative SNP can be also provided here for
%= further visualization
% dataID = 'ABD159-rmdup-clipOverlap-freebayes'; bkgrID = 'ABD241-rmdup-clipOverlap-freebayes'; chr0 = 2; x0 = 17521246;
% dataID = 'ABD173-rmdup-clipOverlap-freebayes'; bkgrID = 'ABD241-rmdup-clipOverlap-freebayes'; chr0 = 3 ; x0 = 1619248;
% dataID = 'ABD159-rmdup-clipOverlap-mpileup';

% dataID = 'HL10';  chr0 =  3 ;  x0 =  16473265;
 dataID = 'HL7_Paired-rmdup-clipOverlap-freebayes'; x0 = 5672441; chr0 = 1;
disp(['=======  Processing data from the run ''', dataID, ''' ======='])
%=       load the recombination map (contains positions of the markers
%= and genetic distance in cM between them)
load ChrMap
%= construct the path to the (primary experimental) data file
dataPath = fullfile('data', [dataID, '-ems-annotation-repfilt.csv'] );
%= extract the refenece reads if the reference ID is given:
RR = loadAndPreprocessReadData(dataPath);


Alpha = 10.^(-0.5:0.25:3);

[ AR, cSlctChrLp, cStatChrLp, neutralEvidenceThrNorm, normFactor, totIntChrSum ] = ...
    runVarAlpha(RR,  Alpha, ChrMap, 1 );

save('dataID', 'AR', 'cSlctChrLp', 'cStatChrLp', 'neutralEvidenceThrNorm', 'normFactor', 'totIntChrSum', 'Alpha')
% %%
load('dataID')

close all

for chr = 1:5
    figure('name', sprintf('chr %u', chr))
    plot(Alpha, totIntChrSum(chr,:)- neutralEvidenceThrNorm(chr,:), 'r-' , 'linewidth',2 );
    hold all
    plot(Alpha, cSlctChrLp(chr,:) - neutralEvidenceThrNorm(chr,:),'g--', 'linewidth',2 );
    plot(Alpha, cStatChrLp(chr,:) - neutralEvidenceThrNorm(chr,:),'b:', 'linewidth',2 );
   
    set(gca, 'xscale', 'log')
    %     plot(Alpha, ,':', 'linewidth',2 );
%     fig(gcf)
%     export_fig(sprintf('figures/alpha_chr%u', chr), '-eps')
end



PlogAlpha = log10(normpdf(log10(Alpha), 0, 0.5));

for chr = 1:5
    figure('name', sprintf('Posterior chr %u', chr))
    plot(Alpha, PlogAlpha + totIntChrSum(chr,:)- neutralEvidenceThrNorm(chr,:), 'r-' , 'linewidth',2 );
    hold all
    plot(Alpha, PlogAlpha + cSlctChrLp(chr,:) - neutralEvidenceThrNorm(chr,:),'g--', 'linewidth',2 );
    plot(Alpha, PlogAlpha + cStatChrLp(chr,:) - neutralEvidenceThrNorm(chr,:),'b:', 'linewidth',2 );
   
    set(gca, 'xscale', 'log')
    %     plot(Alpha, ,':', 'linewidth',2 );
%     fig(gcf)
%     export_fig(sprintf('figures/alpha_chr%u', chr), '-eps')
end


%%
figure('name', 'first derivative');
col = ['b','g','r', 'c', 'm'];
for chr = 1:5
plot(Alpha(2:end)', diff(cSlctChrLp(chr,:), 1, 2)' , [col(chr),'-'])
hold all
plot(Alpha(2:end)', diff(cStatChrLp(chr,:), 1, 2)' , [col(chr),':'])
hold on
end
set(gca, 'xscale', 'log')

figure
plot(Alpha, sum(cStatChrLp, 1),'b:', 'linewidth',2 );
hold all
plot(Alpha, sum(cSlctChrLp, 1),'g--', 'linewidth',2 );
set(gca, 'xscale', 'log')
plot(Alpha, sum(cSlctChrLp+cStatChrLp, 1)/2,'r--', 'linewidth',2 );

figure('name', 'tot posterior')
plot(Alpha, sum(cSlctChrLp+cStatChrLp, 1)+ PlogAlpha,'r--', 'linewidth',2 );
set(gca, 'xscale', 'log')

% ( diff(cSlctChrLp, 2, 2) <= 0)

for chr = 1:5
    figure('name', sprintf('chr %u - total', chr))
    plot(Alpha, totIntChrSum(chr,:)', '-' , 'linewidth',2 );
    set(gca, 'xscale', 'log')
end

    
figure('name', 'total likelihood')
% plot(Alpha, PlogAlpha' + calcMarginalDim(calcMarginalDim(cat(3, log10(4/5)+cStatChrLp, log10(1/5)+cSlctChrLp ), 3),1)' ) 
plot(Alpha, sum(sum(cat(3, log10(4/5)+cStatChrLp, log10(1/5)+cSlctChrLp ), 3),1)' ) 
set(gca, 'xscale', 'log')
hold all


figure('name', 'normFactor')
plot(Alpha, normFactor) 
 set(gca, 'xscale', 'log')

figure
plot(Alpha, log10(-normFactor) )
set(gca, 'xscale', 'log')

chrInds = (AR.chromosome == chr0);

figure
surf(Alpha ,AR.x(chrInds), AR.logPoSlct(chrInds, :), 'linestyle', 'none')
xlabel('\alpha'); ylabel('x')


aa = 2;
figure
plot(AR.x(chrInds), AR.logPoSlct(chrInds, aa), 'linewidth',2 );
fig(gcf)

figure
plot(Alpha, AR.logPoSlct(find(AR.x == x0),: ), 'linewidth',2 );
fig(gcf)
% export_fig(sprintf('figures/alpha_true', chr), '-eps')


% clear EmMatrix