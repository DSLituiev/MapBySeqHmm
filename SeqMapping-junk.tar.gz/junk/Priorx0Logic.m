function Px0 = Priorx0Logic(ExNsSt)
Px0 = ExNsSt*[1,4,16]';
Px0 = Px0./sum(Px0);
% Px0 = 0.01 + 0.99.*ExNsSt(:,1).*(0.1+0.3.*ExNsSt(:,2)+0.6.*ExNsSt(:,3));
