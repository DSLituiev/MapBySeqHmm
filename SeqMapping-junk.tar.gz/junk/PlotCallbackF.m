function output_txt = PlotCallbackF(~,event_obj, lser, flaglog)
% Display the position of the data cursor
% obj          Currently not used (empty)
% event_obj    Handle to event object
% output_txt   Data cursor text string (string or cell array of strings).
% lser         Line series handle vector
% flaglog      boolean: whether to take the log10 of the y-data


pos = get(event_obj,'Position');
targ = event_obj.Target;
chr = find(lser==targ, 1, 'first');

% fprintf('x:\t%8.0f, P:\t%2.2f %%\n', [round(pos(1).*1e6), pos(2).*100])
if flaglog
    output_txt = {['      X : ',num2str(pos(1),4)],...
        ['log10(Y): ',num2str(log10(pos(2)),4)]};
    fprintf(['chr:\t%u\t','x:\t%8.0f\t','log10(P):\t%4.3f\n'],...
        [chr, round(pos(1).*1e6), log10(pos(2))])
else
    output_txt = {['X: ',num2str(pos(1),4)],...
        ['Y: ',num2str(pos(2),4)]};
    fprintf(['chr:\t%u\t','x:\t%8.0f\t','y:\t%4.3f\n'],...
        [chr, round(pos(1).*1e6), pos(2)])
end

% If there is a Z-coordinate in the position, display it as well
if length(pos) > 2
    output_txt{end+1} = ['Z: ',num2str(pos(3),4)];
end
