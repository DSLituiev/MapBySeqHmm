function [Px0, varargout] = Priorx0(DataText)

Exonic = cell2mat(cellfun(@(x)strcmpi(x,'Exonic'),DataText(:,1),'UniformOutput',0));
NonSynonimous = cell2mat(cellfun(@(x)strcmpi(x,'NS'),DataText(:,2),'UniformOutput',0));
Stops = cell2mat(cellfun( @(x)~isempty(regexpi(x,'\*','start')), DataText(:,3),'UniformOutput',0));

Px0 = 0.01 + 0.99.*Exonic.*(0.1+0.3.*NonSynonimous+0.6.*Stops);
varargout(1) = {[Exonic,NonSynonimous,Stops]};