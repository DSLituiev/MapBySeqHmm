close all; clear all; clc;
dbclear if warning
tic

addpath('D:\MATLABuserfunctions\binomial');
addpath('D:\MATLABuserfunctions\mtimesx');
addpath('D:\MATLABuserfunctions\MinMaxSelection');
addpath('D:\MATLABuserfunctions\newtonraphson');
addpath('D:\MATLABuserfunctions'); savepath;
addpath('.\utilites');
addpath('.\betabinomial');
% addpath('..\@chromProb');
addpath('.');

%=       provide the reference ID, which is the name of the csv file without '.csv'
%= together with the backround genotype ID
%= known positions of the causative SNP can be also provided here for
%= further visualization
% dataID = 'ABD159-rmdup-clipOverlap-q20-freebayes'; chr0 = 2; x0 = 17521246; % bkgrID = 'ABD241-rmdup-clipOverlap-freebayes';
% dataID = 'ABD173-rmdup-clipOverlap-freebayes'; chr0 = 3 ; x0 = 1619248; % bkgrID = 'ABD241-rmdup-clipOverlap-q20-freebayes';


dataID = 'HL10-rmdup-clipOverlap-q20-freebayes';  chr0 =  3 ;  x0 =  16473265;

% dataID = 'HL7_Paired-rmdup-clipOverlap-freebayes'; x0 = 5672441; chr0 = 1;
%  dataID = 'HL7_Paired-rmdup-clipOverlap-q20-freebayes'; x0 = 5672441; chr0 = 1;
% dataID = 'HL7_Paired-ngm-rmdup-clipOverlap-freebayes'; x0 = 5672441; chr0 = 1;
% dataID = 'HL7_Paired-rmdup-clipOverlap-mpileup'; x0 = 5672441; chr0 = 1;

disp(['=======  Processing data from the run ''', dataID, ''' ======='])
%= and genetic distance in cM between them)
load ChrMap
%% general experimental constants:
%= number of plants:
N = 50;
study = population(N);
%%
% mkdir(fullfile('figures',dataID))
%=       load the recombination map (contains positions of the markers
%= and genetic distance in cM between them)

%= construct the path to the (primary experimental) data file
dataPath = fullfile('./data', [dataID, '-ems-annotation-repfilt.csv'] );
%= extract the refenece reads if the reference ID is given:
clear AR1 AR z y
[AR, annotation] = subtractBackGroundGenotype(dataPath);

AR = calcDxMin(AR);

AR = unmix(AR);

% [AR, mu, iT, ~] = unmixRepeatsOne( AR, 'dx', '','modeNum', 2);
%%

% [AR, mu, ~, mixtObj, fh] = unmixRepeatsOne( AR, 'dx', 'plot','modeNum', 2);
% fig(fh(3), 'height', 15, 'width', 12)
% exportfig(fh(3), fullfile('../figures', [dataID, '-scatter']), 'format','eps', 'color', 'rgb')
%
% fig(fh(4), 'height', 12, 'width', 12)
% exportfig(fh(4), fullfile('../figures', [dataID, '-dx_hist']), 'format','eps', 'color', 'rgb')
%
% figure('name','true')
% hist( log10( double(AR.r(AR.contrib>0.5)) ), 20)
%
% figure
% hist(log10(double(AR.r(AR.contrib<0.5)) ) , 20)
%
%
%
% figure('name','true')
% [yh,xh] = hist( (AR.f(AR.r>50)), 20);
% bar(xh,yh./sum(yh))
% hold on
% plot([1,1]*0.5, [0,1]*0.3, 'r-')
% xlim([0,1]); ylim([0,1]*0.3)
% fig(gcf, 'height', 8, 'width', 12)
% exportfig(gcf, fullfile('../figures', [dataID, '-f_hist']), 'format','eps', 'color', 'rgb')
%
% return
%%

[theta, lambda1, ~] = runSimpleEM_BetaBinomAndUniform(double(AR.q),...
    double(AR.r), study.N, 'v',...
    'errTol', 1e-6);% , 'contribution', AR.contrib);

emissionHandle = @(q, r, study)emissionMixBetaBinomial(q, r, study, theta, lambda1);
%  emissionHandle = @(q, r, study)emissionBetaBinomial(q, r, study, theta);
% emissionHandle = @(qq, rr, ff)emissionk0(qq, rr, study);

% AR.contrib = ones(size(AR.x));
[AR.E, AR.c] = wrapEmissionMatrix(AR.q, AR.r, study, emissionHandle, AR.contrib);
% Alpha = 10.^[-5:.25:0];% 
da = 0.01;
Alpha =[1e-10, da:da:1, 1./(1:-da:da), 1e10];


for chr = AR.chromosomeNumber:-1:1
    
    fprintf('chromosome \t%u\n' , chr)
    
    inds = (AR.chromosome == chr);
    clear  y %outLLsel outLLstat
    y =  getChromosome(AR, chr,  'new');
    
    for aa = numel(Alpha):-1:1
        
        distanceM = 1./Alpha(aa) * 0.01* recdistances(ChrMap(chr), AR.x(inds));
        %= calculate Transition matrices
        T = transition3D_expm( study.N, abs(diff(distanceM)) );
        y.T = T;
        [y, fh] = y.run();
        outLLsel{chr}(:,aa) = y.Psel;
        outLLstat{chr}(:,aa) = y.Pstat;        
        outLLflat{chr}(:,aa) = y.Pflat;
        
        x{chr} = y.x;
%         [y, fh] = y.run('plot');
%         set(fh, 'name', sprintf('chr %u, \alpha = %d', chr, Alpha(aa)));
    end
end

chr = chr0;

figure
surf(x{chr}, Alpha, outLLsel{chr}', 'linestyle', 'none')
view(0,90)
 set(gca, 'yscale', 'log')
 
margLLsel = calcMarginal(outLLsel{chr},1) - log10(numel(Alpha));

figure
plot(Alpha, margLLsel, 'r-')
hold all
plot(Alpha, calcMarginal(outLLstat{chr},1), 'g-')
plot(Alpha, calcMarginal(outLLflat{chr},1), 'b-')
 set(gca, 'xscale', 'log')

[~, optAlphaInd ] = max(margLLsel);

figure
plot(x{chr}, outLLsel{chr}(:, optAlphaInd), 'r-')
hold all
plot(x{chr}, calcMarginal(outLLsel{chr}(:, ~any(isnan(outLLsel{chr}), 1)), 2), 'g-')
plot(x0*[1,1], [min(outLLsel{chr}(:, optAlphaInd)), max(outLLsel{chr}(:, optAlphaInd))])

figure
surf(x{chr}, Alpha, outLLstat{chr}', 'linestyle', 'none')
view(0,90)
 set(gca, 'yscale', 'log')
 
margLLstat = calcMarginal(outLLstat{chr},1) - log10(numel(Alpha));
[~, optAlphaInd ] = max(margLLstat);

figure
plot(x{chr}, outLLstat{chr}(:, optAlphaInd), 'r-')
hold all
plot(x{chr}, calcMarginal(outLLstat{chr}(:, ~any(isnan(outLLstat{chr}), 1)), 2), 'g-')

%%

return
% ff =  0:(1/2/N):(1);
q1 = 25;
q2 = 60;
figure
plot(f, (binopdf(25,100,f)) , 'g-' , 'linewidth', 2)
hold all
plot(f, 10.^logBetaBinomialThetaMu0(q1 ,100,f, theta), 'm-', 'linewidth', 2)
plot(f, (1-lambda1)*1/N + lambda1*10.^logBetaBinomialThetaMu0(q1 ,100,f, theta), 'r-', 'linewidth', 2)
plot(f, (binopdf(q2 ,100,f)) , 'g:', 'linewidth', 2)
plot(f, 10.^logBetaBinomialThetaMu0(q2 ,100,f, theta) , 'm:', 'linewidth', 2)
plot(f, (1-lambda1)*1/N + lambda1*10.^logBetaBinomialThetaMu0(q2,100,f, theta), 'r:', 'linewidth', 2)
legend({'binomial', '\beta-binomial', '\beta-binomial + uniform'})
fig(gcf, 'height', 12, 'width', 16)

% exportfig(gcf, fullfile('../figures', ['demo-beta-mix']), 'format','eps', 'color', 'rgb')
