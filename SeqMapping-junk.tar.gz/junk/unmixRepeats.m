function [ dataStruct, mu, iTrue2, mixtObj ] = unmixRepeats( dataStruct, firstParam, varargin )
% UNMIXREPEATS represents a bi-variate distribution of the given
% log-scaled feature and read log-number of reads per each locus as a
% mixture of Gaussians (GMM) and performs logistic classification
% based on the submitted assumption about the localization of the 'true' peak.
%
%     The Bayesian information criterium (BIC) is used to chose the number of
% mixing modes with the lowest allowed number of modes of 2.
%
% The logarithmic base of 10 is used throughout this script
%
% ====================== INPUT  ======================
%
% dataStruct       -- a structure with the obligatory field 'r'
%                    (read number in the locus), which is used as
%                     the second feature for classification
%                     and  the field 'notaRepeat' (logical) used for
%                     visualization purposes
% firstParam       -- the name of the field to be used as
%                     the first feature for classification
%
% ____________ optional variables and flags ____________
% 'plot'           -- visualize the results
% 'modeNum': 4     -- maximum number of modes to be tested
% 'repeateEM':  20 -- number of iterations of GMM algorithm
% 'C_CONTR' : 1/16 -- 'rigidness' of the margin between true and spurious reads
% 'B_CONTR' : 0    -- the lower 'contribution' value for spurious reads
% 'peakVar1': 'max'-- function to use for finding the 'true' peak (feature #1)
% 'peakVar2': 'min'-- function to use for finding the 'true' peak (feature #2)
%              possible values:
%             'max', 'min', 'median', 'none'
%
% ====================== OUTPUT  ======================
%
% dataStruct       -- the structure given in the input with a new field
%                    'contrib' for responsivity/contribution/ believe
%                     that each read comes from the 'true' distribution
% mu               -- a structure of means with two vector fields
%                     corresponding to the features used for classification
% iTrue2           -- the subscipt of the 'true' mean in the vector 'mu'
%

%% check the input parameters
p = inputParser;
addRequired(p, 'OR', @isstruct);
addRequired(p, 'firstParam', @(x)isfield(dataStruct, x));
%
addOptional(p,'plotFlag', '', @ischar);
%
addParamValue(p,     'modeNum',             4, @isscalar);
addParamValue(p,     'repeateEM',          20, @isscalar);
addParamValue(p,     'C_CONTR',          1/16, @isscalar);
addParamValue(p,     'B_CONTR',             0, @isscalar);
addParamValue(p,     'peakVar1',            'max',...
    @(x)(isa(eval(['@',x]), 'function_handle')) || strcmpi(x, 'none') );
addParamValue(p,     'peakVar2',            'min', ...
    @(x)(isa(eval(['@',x]), 'function_handle')) || strcmpi(x, 'none') );

parse(p, dataStruct, firstParam, varargin{:});

%% assign optional variables
C_CONTR = p.Results.C_CONTR;
B_CONTR = p.Results.B_CONTR;
repeateEM = p.Results.repeateEM ;
modeNum = p.Results.modeNum;
if modeNum<2
    modeNum = 2;
end
%%
%= select the first feature according to the input variable
x1 = double(dataStruct.(firstParam));
%= combine the log-scaled feature vectors into one array
    logX1 = log10( x1(~isnan(x1)) );
    logX2 = log10(double(dataStruct.r(~isnan(x1)) ) );

X0 = [logX1, logX2];
%= select non-repeatitive reads
XX = X0( dataStruct.notaRepeat, : );

% st.mu = [2 6; 5 1];
% st.Sigma = cat(3,[.2 0;0 1],[.1 0;0 1]);
% st.PComponents = ones(1,2)/2;
% obj = gmdistribution.fit(XX ,k, 'Start', st);

%% calculate GMM for a number of mixture components ii = 2...modeNum
dbclear if warning
warning('off','stats:gmdistribution:FailedToConverge')
for ii = modeNum:-1:1
    obj0 = gmdistribution.fit(XX , ii, 'Replicates', repeateEM);
    mixt(ii).obj = obj0;
    mixtBICs(ii) = obj0.BIC;
end
%= find the BIC-optimal number of the mixture components ( >=2 )
[~, iMaxObj] = min( mixtBICs );
%= use the BIC-optimal GMM parameters
mixtObj = mixt( iMaxObj ).obj;

clear ii obj0 mixt iMaxObj

%% select the 'correct' and 'false' peaks
if strcmpi(p.Results.peakVar1 , 'none')
    iTrue1 = NaN;
    iFalse1 = NaN;
else
    if strcmpi(p.Results.peakVar1 , 'max')
        [~, iTrue1] = max(mixtObj.mu(:,1)); % dx
        [~, iFalse1] = min(mixtObj.mu(:,1)); % dx
    elseif strcmpi(p.Results.peakVar1 , 'min')
        [~, iTrue1] = min(mixtObj.mu(:,1)); % dx
        [~, iFalse1] = max(mixtObj.mu(:,1)); % dx
    elseif strcmpi(p.Results.peakVar1 , 'median')
        iTrue1 = floor(numel(mixtObj.mu(:,1))/2)+1;
        iFalse1 = NaN;
    end
end
%=====================
if strcmpi(p.Results.peakVar2 , 'none')
    iTrue2 = NaN;
    iFalse2 = NaN;
else
    if strcmpi(p.Results.peakVar2 , 'max')
        [~, iTrue2] = max(mixtObj.mu(:,1)); % dx
        [~, iFalse2] = min(mixtObj.mu(:,1)); % dx
    elseif strcmpi(p.Results.peakVar2 , 'min')
        [~, iTrue2] = min(mixtObj.mu(:,2)); % r
        [~, iFalse2] = max(mixtObj.mu(:,2)); % r
    elseif strcmpi(p.Results.peakVar2 , 'median')
        iTrue2 = floor(numel(mixtObj.mu(:,1))/2)+1; % dx
        iFalse2 = NaN;
    end
end
%=====================
%= calculate the odds that the SNP locus comes from the 'true' distribution
if (iTrue1 == iTrue2)
    piTrue = mixtObj.PComponents(iTrue2);
    PrTrue = mvnpdf(X0, mixtObj.mu(iTrue2,:), mixtObj.Sigma(:,:,iTrue2));
    Odds = (1-piTrue)* PrTrue./(pdf(mixtObj, X0) - piTrue * PrTrue );
    Contr = (piTrue)* PrTrue./pdf(mixtObj, X0);
elseif (iFalse1 == iFalse2)
    piFalse = mixtObj.PComponents(iFalse2);
    PrFalse = mvnpdf(X0, mixtObj.mu(iFalse2,:), mixtObj.Sigma(:,:,iFalse2));
    Odds = (pdf(mixtObj, X0) - piFalse.* PrFalse )./((1-piFalse)* PrFalse);
    Contr = piFalse * PrFalse./pdf(mixtObj, X0);
elseif strcmpi(p.Results.peakVar1 , 'none')
    warning('unmixRepeats:iDx_NotEqual_iR','strange mixture separation')
    piTrue = mixtObj.PComponents(iTrue2);
    PrTrue = mvnpdf(X0, mixtObj.mu(iTrue2,:), mixtObj.Sigma(:,:,iTrue2));
    Odds = (1-piTrue)* PrTrue./(pdf(mixtObj, X0) - piTrue * PrTrue );
    Contr = (piTrue)* PrTrue./pdf(mixtObj, X0);
else
    warning('unmixRepeats:iDx_NotEqual_iR','strange mixture separation')
    piTrue = mixtObj.PComponents(iTrue1);
    PrTrue = mvnpdf(X0, mixtObj.mu(iTrue1,:), mixtObj.Sigma(:,:,iTrue1));
    Odds = (1-piTrue)* PrTrue./(pdf(mixtObj, X0) - piTrue * PrTrue );
    Contr = (piTrue)* PrTrue./pdf(mixtObj, X0);
end
%  Pr2 = mvnpdf(X0, obj.mu(1,:), obj.Sigma(:,:,1));
%  Pr1 = mvnpdf(X0, obj.mu(2,:), obj.Sigma(:,:,2));
%  Odds0 = Pr2./Pr1;

% calculate 'contribution'/'responsivity' based on odds
% figure; hist(Contr)
dataStruct.contrib = Contr./max(Contr);% B_CONTR + (1 - B_CONTR)./(1 + C_CONTR./Odds);

if any(dataStruct.contrib > 1)
    warning('CumMatr:ENegInput', 'contrib > 1 !')
end

%% assign the mean values
mu.(firstParam) =  mixtObj.mu(:,1) ;
mu.r  = mixtObj.mu(:,2);

%% visualize the results if requested
if strcmpi(p.Results.plotFlag, 'plot')
    
    %==
    figure('name', 'mixture: estimated PDFs for non-repetitive regions')
    scatter( logX1(dataStruct.notaRepeat),  logX2(dataStruct.notaRepeat) , 3,...
        pdf(mixtObj, [logX1(dataStruct.notaRepeat), logX2(dataStruct.notaRepeat) ]) );
    hold all
    %     plot(model.m(1,:), model.m(1,:), 'rx', 'MarkerSize', 7)
    xlabel( firstParam )
    ylabel('\it r')
    title('non-repeatitive')
    ax(1) = gca;
    %=======================================
    figure('name', 'contribution assigned to the components')
    scatter( logX1,  logX2, 3,  dataStruct.contrib);
    xLim = get(gca, 'xlim');
    yLim = get(gca, 'ylim');
    nPoints = 50;
    cLevels = [1, 5, 10, 25, 50, 75, 90, 95, 99];
    hold all
    plot(mixtObj.mu(:,1), mixtObj.mu(:,2), 'kx', 'MarkerSize', 8, 'LineWidth', 2)
    [X, Y] = meshgrid(linspace(xLim(1), xLim(2), nPoints), linspace(yLim(1), yLim(2), nPoints) );
    
    h = contour(X, Y, reshape(pdf(mixtObj, [X(:), Y(:)]), [nPoints,nPoints]), cLevels );
    %     h = ezcontour(@(x,y)pdf(obj, [x y]), [xLim, yLim]);
    if exist('h', 'var') && all(ishandle(h(:)))
        set(h, 'linewidth', 2);
        set(h, 'LevelList', [0.5, .75, .9, .95]);
    end
    xlabel( firstParam )
    ylabel('\it r')
    title('')
    ax(2) = gca;

    %=======================================
    figure('name', 'mixture: estimated PDFs')
    %---------------------
    sp(1) = subplot(1,3,1);
    scatter(  logX1,  logX2, 3,...
        pdf(mixtObj, [logX1,  logX2]) );
    hold all
    plot(mixtObj.mu(:,1), mixtObj.mu(:,2), 'kx', 'MarkerSize',8, 'LineWidth', 2)
    xlabel( firstParam )
    ylabel('\it r')
    title('all')
    %---------------------
    sp(2) = subplot(1,3,2);
    scatter( logX1(dataStruct.notaRepeat), logX2(dataStruct.notaRepeat) , 3,...
        pdf(mixtObj, [logX1(dataStruct.notaRepeat),  logX2(dataStruct.notaRepeat) ]) );
    hold all
    plot(mixtObj.mu(:,1), mixtObj.mu(:,2), 'kx', 'MarkerSize', 8, 'LineWidth', 2)
    xlabel( firstParam )
    ylabel('\it r')
    title('non-repeatitive')
    %---------------------
    sp(3) = subplot(1,3,3);
    scatter(   logX1(~dataStruct.notaRepeat),  logX2(~dataStruct.notaRepeat) , 3,...
        pdf(mixtObj, [ logX1(~dataStruct.notaRepeat),  logX2(~dataStruct.notaRepeat) ]) );
    hold all
    plot(mixtObj.mu(:,1), mixtObj.mu(:,2), 'kx', 'MarkerSize', 8, 'LineWidth', 2)
    xlabel( firstParam )
    ylabel('\it r')
    title('repeatitive')
    %-------------------
     set(sp, 'xlim', [ .5*floor(2*min(logX1)), .5*ceil(2*max(logX1)) ])
     set([sp(:); ax(:)], 'ylim', [ floor(min(logX2)), ceil(quantile(logX2, .9)) ])
%         set(sp, 'ylim', [ floor(min(logX2)), ceil(max(logX2)) ])

end

end

