classdef readData < handle
    properties
        chromosome
        x
        q
        r
        f
        qual % quality
        notaRepeat;
        dx;
        contrib;
        c;
        E;
        xLL; % log-likelihood of observed data
        xLPost % log-posterior
        chrNumber;
        Mtot;
        M;
        annotation;
    end
    
    methods
        function obj = readData(chromosome, x,q,r, varargin)
            if nargin>0 && numel(q) == numel(x) && numel(r) == numel(x)
                obj.chromosome = chromosome;
                obj.x = x;
                obj.q = q;
                obj.r = r;
                obj.f = q./r;
                obj.chrNumber = max(chromosome);
                obj.Mtot = numel(x);
                if (nargin>5)
                    obj.qual = varargin{1};
                    obj.notaRepeat = varargin{2};
                    %                     if (nargin>6)
                    %                         obj.annotation = varargin{3};
                    %                     end
                end
            end
        end
        
        function obj = calcDxMin( obj )
            obj = calcDx(obj,  @(x)nanmin(x, [], 2));
        end
        
        function obj = calcDx( obj, fh )
            for cc = obj.chrNumber: -1:1
                inds = logical(cc == obj.chromosome);
                dxRaw = [NaN; diff(double(obj.x(inds)))];
                dxRaw( dxRaw < 0) = NaN;
                dxPair = [dxRaw, circshift(dxRaw,-1)];
                obj.dx(inds,1) = feval( fh, dxPair);
            end
        end
        
        function obj = unmix(obj, varargin)
            if nargin>1 && ~isempty(varargin{1})
                plotFl = varargin{1};
            else
                plotFl = '';
            end
            [obj, mu, iT, ~] = unmixRepeatsOne( obj, 'dx', plotFl,'modeNum', 2);
        end
        
        %% chromosome retrieval
        function subobj = getChromosome(obj, cc, varargin)
            if nargin>2 && any(strcmpi('old', varargin))
                subobj = chromProbO();
            else
                subobj = chromProb();
            end
             mcObj= metaclass(obj);
             mcObj.PropertyList;
            propNames = properties(obj);
            inds = logical(cc == obj.chromosome);
            
            for ii = 1:numel(mcObj.PropertyList)                
                if any(strcmpi(mcObj.PropertyList(ii).Name, properties(subobj)))
                    s = size(obj.(propNames{ii}),1);
                    switch s
                        case obj.Mtot
                            subobj.(propNames{ii}) = obj.(propNames{ii})(inds, :);
                        case obj.chrNumber
                            subobj.(propNames{ii}) = obj.(propNames{ii})(cc, :);
                        otherwise
                            subobj.(propNames{ii}) = obj.(propNames{ii});
                    end
                end
            end
            subobj.M = sum(inds);
        end
        %%
        function obj = chrInds(obj)
            obj.ci = cell(obj.chrNumber, 1);
            for chr = 1: obj.chrNumber
                obj.ci{ chr } = (obj.chromosome == chr);
                obj.cs(chr) = find( obj.ci{chr}, 1, 'first');
                obj.M(chr) = sum( obj.ci{ chr });
            end
        end
    end
end