function [A, DD] = DistComplHaldane(dvect)
% returns complementary Haldane's function and pairwise recombinational distance
% input: 
% dvect -- vector of recombiantional positions of loci
[XX, YY] = meshgrid(dvect,dvect);
DD = YY-XX; 
A = exp(-abs(DD)).*cosh(DD);