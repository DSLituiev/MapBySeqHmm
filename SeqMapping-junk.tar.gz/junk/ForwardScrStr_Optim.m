% Main script
%==== Do coverage penalty after the filtering
%==== Analyse diff(x)! -- should be Poisson

close all; clear all; clc; dbclear all
tic
addpath('D:\MATLABuserfunctions\mtimesx');
addpath('D:\MATLABuserfunctions\MinMaxSelection');
addpath('D:\MATLABuserfunctions'); savepath;
addpath('.\utilites');

%=       provide the reference ID, which is the name of the csv file without '.csv'
%= together with the backround genotype ID
%= known positions of the causative SNP can be also provided here for
%= further visualization
dataID = 'ABD159-rmdup-clipOverlap-freebayes'; bkgrID = 'ABD241-rmdup-clipOverlap-freebayes'; chr0 = 2; x0 = 17521246;
% dataID = 'ABD173-rmdup-clipOverlap-freebayes'; bkgrID = 'ABD241-rmdup-clipOverlap-freebayes';
% dataID = 'ABD173-rmdup-clipOverlap-freebayes'; bkgrID = 'ABD241';
%  dataID = 'HL10';
%  dataID = 'HL7'; x0 = 5672441; chr0 = 1;
disp(['=======  Processing data from the run ''', dataID, ''' ======='])
%=       load the recombination map (contains positions of the markers
%= and genetic distance in cM between them)
load ChrMap
%= construct the path to the (primary experimental) data file
dataPath = fullfile('data', [dataID, '-ems-annotation-repfilt.csv'] );
%= extract the refenece reads if the reference ID is given:
if exist( 'bkgrID', 'var' )
    refPath = fullfile('data', [bkgrID, '-ems-annotation-repfilt.csv'] );
    [AR, annotation] = subtractBackGroundGenotype(dataPath, refPath);
else
    [AR, annotation] = subtractBackGroundGenotype(dataPath);
end

visualizeAnnotationStat(annotation)
[AR.logPrior, AR.maxHitGene, AR.maxHitEffect,...
    AR.positionCDS, AR.effectAA, AR.effectCodone] = constructPriorStr(annotation);
% clear annotation

% clc; for ii = 70:170; fprintf('ii = %2u\n', ii); disp(AR.ann(ii).eff); end
%% crucial filtering parameters:
%== read number margins
filt.q_min = 3;
filt.r_up_quantile =  0.95;
filt.qual_thr = 10;
filt.f_max  = .75;
%%

analyseReadNumVsFreqDistribution( AR)

[ obj ] = analyseReadNumberDistribution( AR.r, 'modeNum',3 );


[ obj ] = analyseReadNumberDistribution( AR.q, 'modeNum',3 );

[ obj ] = analyseReadNumberDistribution( double(AR.r) - double(AR.q), 'modeNum',3 );

%= calculate the mean distance to the two neighbouring loci for each locus
AR = calcDx(AR);
%=     find characteristic length scale for the 'correct' SNPs
%= as the mode for 'correct' SNP fraction (uses log-Gaussian mixture model)
[AR, mu, ~] = unmixRepeats( AR, 'dx', 'plot' );
%= the characteristic length scale
sigmaDx = 2*10^max(mu.dx);
%= calculate the smoothed SNP density (SNP sites / bp)
AR.W = calcReadDensity( AR.x, sigmaDx );

[AR, mu, iTrue] = unmixRepeats( AR, 'W', 'plot', 'modeNum', 3,...
    'peakVar1', 'min', 'peakVar2', 'median' );
% RR = selectFieldIndices(RR, inds);
%== plot the smoothed density estimate
markerSz = 4;
[f, spl] = plotAllChrNt(AR, 'W', 'exp10', true, 'ylim', 10.^[0 20],...
    'plotfun',@(x,y)plot(x,y,'MarkerEdgeColor','r', ...
    'MarkerSize', markerSz, 'Color', 'r'),...
    'FigName', 'Density', 'yscale', 'log' );

%== plot the read number per locus
[f, spl] = plotAllChrNt(AR, 'r', 'exp10', true,...
    'plotfun',@(x,y)plot(x,y, 'x', ...
    'MarkerEdgeColor','g',  'MarkerSize', markerSz, 'Color', 'g'),...
    'FigName', 'Density', 'yscale', 'log', 'OldFig', f, 'OldSP', spl );

%%
%== plot the 'contribution' (responsibility) of the true distribution in
% each read
[f, spl] = plotAllChrNt(AR, 'contrib', 'exp10', false, 'ylim', [0 1],...
    'plotfun',@(x,y)plot(x,y,'MarkerEdgeColor','r', ...
    'MarkerSize', markerSz, 'Color', 'r'),...
    'FigName', 'Contribution', 'yscale', 'lin' );

%== discard reads in repeat regions
% [ RR ] = selectFieldIndices( AR , ~AR.notaRepeat);
% [ RR ] = selectFieldIndices( AR ,AR.notaRepeat & AR.contrib>.2 & AR.f < .65 & AR.r < 1e3 );
RR = AR;

%% filter
filt.r_max = quantile(RR.r, filt.r_up_quantile);
inds = ( RR.qual>=10 &...
    RR.q >= filt.q_min &...
    RR.r < filt.r_max &...
    RR.f < filt.f_max );
%= r
RR.contrib(~inds) = 0.1;


%%
clear AR;
clear Description
%= plot the SNP ratio
% [f, spl] = plotAllChrNt(RR, 'f', 'exp10', false, 'ylim', [0 1],...
%     'plotfun',@(x,y)plot(x,y,'MarkerEdgeColor','r', ...
%     'MarkerSize', markerSz, 'Color', 'r'),...
%     'FigName', 'Density', 'yscale', 'lin' );

%% general experimental constants:
%= number of plants:
study.N = 50;
%= number of potentially positive plants by a SNP:
study.kvect = uint32(0: 1: study.N)';
%= number of chromosomes:
study.chrnum = length(ChrMap);
%== cutoff for emission calculation
CUT_READ_NUM_BINOM = 120;
%% approximate binomial by Gaussian for high numbers
[EmMatrix, limReads] = initializeLimEmissionMatrix(study, RR, CUT_READ_NUM_BINOM);
%% flags
flag.prior = isfield(RR, 'logPrior'); %== use prior if available

%% initialization of the Calculation loop
M = zeros(study.chrnum, 1);  % number of reads on the chromosome
%= log-likelihood of the chromosome to be stationary
statChrLogProb = zeros(study.chrnum, 1);
%= log-likelihood of the chromosome to be under selection
slctChrLogProb = zeros(study.chrnum, 1);
%= log-likelihood of the locus to be under selection (within chromosome)
RR.logPoSlctChr = zeros(size(inds));
%=

Alpha = 10.^(-0.5:0.5:4);
%%   Calculation cycle
for chr = 1: study.chrnum;
    ticInit = tic;
    
    [ inds, M(chr), x, q, r,  contrib ] = recastChromosomeReads( RR(1), chr );
    
    for aa = 1:numel(Alpha)
        [  RR.logPoSlct(inds,aa), slctChrLogProb(chr, aa), statChrLogProb(chr,aa) ]  = ...
            estimateLikelihoodsOnChromosome( ChrMap(chr), EmMatrix, limReads, study.N,...
            x, q, r, contrib, Alpha(aa));
    end
    %== check for NaNs
    
    fprintf('\t The iterations for the chr.#\t%u\t took \t%4.2f\t s \t SNPs:\t%u \n', chr, toc, sum(inds) )
    %== Ready!
end

y = -Inf(numel(RR.x), numel(Alpha));
for chr = 1:5
    figure('name', sprintf('chr %u', chr))
    plot(Alpha, slctChrLogProb(chr,:), 'linewidth',2 );
    hold all
    plot(Alpha, statChrLogProb(chr,:),':', 'linewidth',2 );
    set(gca, 'xscale', 'log')
    %     fig(gcf)
    %     export_fig(sprintf('figures/alpha_chr%u', chr), '-eps')
    
    
    chrInds = (RR.chromosome == chr);
    y(chrInds,:) = bsxfun( @minus, RR.logPoSlct(chrInds, :), statChrLogProb(chr,:));
    
    infA(:,chr) = sum(y(chrInds,:).*10.^y(chrInds,:), 1)';
end



figure('name', sprintf('information chr %u', chr))
plot(Alpha, infA )
set(gca, 'xscale', 'log')


figure('name', sprintf('information chr %u', chr))
plot(Alpha, sum(infA, 2), 'linewidth', 2 )
set(gca, 'xscale', 'log')
fig(gcf)

% exportfig(gcf, fullfile('figures',['Information-', dataID]), 'format','eps', 'color', 'rgb')

totLl = calcMarginalDim(RR.logPoSlct);
figure('name', sprintf('total likelihood chr %u', chr))
plot(Alpha(2:end), totLl(2:end), 'linewidth', 2 )
set(gca, 'xscale', 'log')
fig(gcf)



chrInds = (RR.chromosome == chr0);
y = bsxfun( @minus, RR.logPoSlct(chrInds, :), statChrLogProb(chr0,:));

figure
surf(RR.x(chrInds), Alpha, y' , 'linestyle', 'none')
set(gca, 'yscale', 'log')
ylabel('\alpha'); xlabel('x')

figure
plot( double(RR.x(chrInds))*1e-6,  y(:, Alpha==1) , 'r^-', 'markerSize', 4)
hold all
plot( double(RR.x(chrInds))*1e-6,  y(:, Alpha==10) , 'b.--')
plot( double(RR.x(chrInds))*1e-6,  y(:, Alpha==100) , 'gv-.', 'markerSize', 4)
plot( x0*1e-6 * [1, 1], get(gca, 'ylim') , 'k:')
xlabel('x, Mbp'); ylabel('log-likelihood odds');
legend('\alpha = 1','\alpha = 10', '\alpha = 20')
fig(gcf)
%  export_fig(sprintf('figures/%s_chr0_alphas', dataID), '-eps')

for cc = 1: study.chrnum;
    chrInds = (RR.chromosome == cc);
    y(chrInds, :) = bsxfun( @minus, RR.logPoSlct(chrInds, :), statChrLogProb(cc,:));
end

RR.y1 = y(:, Alpha == 1);
RR.y10 = y(:, Alpha == 10);
RR.y20 = y(:, Alpha == 100);

markerSz = 4;
[f, spl] = plotAllChrNt(RR, 'y1', 'exp10', true,...
    'plotfun',@(x,y)plot(x, y, '^-','MarkerEdgeColor','r', ...
    'MarkerSize', markerSz, 'Color', 'r', 'linewidth', 2),...
    'FigName', 'Density', 'yscale', 'log' );

[f, spl] = plotAllChrNt(RR, 'y10', 'exp10', true,...
    'plotfun',@(x,y)plot(x,y, '.-', 'MarkerEdgeColor','b',...
    'MarkerSize', 2*markerSz, 'Color', 'b', 'linewidth', 2),...
    'FigName', 'Density', 'yscale', 'log', 'OldFig', f, 'OldSP', spl );

[f, spl] = plotAllChrNt(RR, 'y20', 'exp10', true, 'ylim', 10.^[-10 20],...
    'plotfun',@(x,y)plot(x,y, 'v-', 'MarkerEdgeColor','g',...
    'MarkerSize', markerSz, 'Color', 'g', 'linewidth', 2),...
    'FigName', 'log-odds', 'yscale', 'log', 'OldFig', f, 'OldSP', spl );
set(spl, 'box', 'on')

axes(spl(chr0)); hold on
plot(x0* [1, 1], get(spl(chr0), 'ylim') , 'k:',  'linewidth', 1)

legend('\alpha = 1','\alpha = 10', '\alpha = 20')

fig(gcf)
export_fig(sprintf('figures/%s_all_chr_alphas', dataID), '-eps')


figure
plot(Alpha, RR.logPoSlct(find(RR.x == x0),: ), 'linewidth',2 );
fig(gcf)
% export_fig(sprintf('figures/alpha_true', chr), '-eps')


% clear EmMatrix
%% calculate P(other chrs are stationary)
I = logical(eye(study.chrnum));
othersStatLogProb = zeros(study.chrnum, 1);
thisSelLogProb = zeros(study.chrnum, 1);
RR.logPoSlctNC = zeros(size(RR.logPoSlct));

for chr = study.chrnum:-1:1
    othersStatLogProb(chr) = sum( statChrLogProb(~I(:,chr)) );
    inds = (RR.chromosome == chr);
    RR.logPoSlct(inds) = RR.logPoSlct(inds) + othersStatLogProb(chr);
    
    RR.logPoSlctNC(inds) =  RR.logPoSlct(inds) -  calcMarginal(RR.logPoSlct(inds));
    %     marg(chr) =  calcMarginal(ObservationReads.logPobsSelection(inds)) ;
    
end
%== dot product:
normFactor = calcMarginal(slctChrLogProb + othersStatLogProb);

RR.logPobsSelectionNorm  = RR.logPoSlct - normFactor;
% thisSelLogProb(chr) = selChrLogProb(chr)

%% plot the likelihood
markerSz = 4;
plotcutoff = -30;
[f, spl] = plotAllChrNt(RR, 'logPoSlctNC','exp10',false,'ylim',[plotcutoff 0],...
    'plotfun',@(x,y)stem(x,y,'MarkerEdgeColor','g',  'MarkerSize', markerSz, 'Color', 'g', 'BaseValue',(plotcutoff-2)),...
    'FigName', 'Likelihood', 'yscale', 'lin' );

%     [f, spl] = plotAllChrNt(ObservationReads, 'logPobsSelection','exp10',true,'ylim',10.^[plotcutoff 0],...
%         'plotfun',@(x,y)stem(x,y,'MarkerEdgeColor','g',  'MarkerSize', markerSz, 'Color', 'g', 'BaseValue',10^(plotcutoff-2)),...
%         'FigName', 'Likelihood');
%

