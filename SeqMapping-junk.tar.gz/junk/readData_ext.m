classdef readDataVect < handle
    properties
        chromosome
        x
        q
        r
        f
        qual % quality
        notaRepeat;
        contrib;
        c;
        E;
        dx;
        T = {};
        A = {};
        logAlpha = {};
        logBeta = {};
        ci = {}; % chromosome indices (cell)
        chrSta; % chromosome start (vector)
        chrEnd; % chromosome end   (vector)
        M; % number of SNPs on each chromosome (vector)
        xLL; % log-likelihood of observed data
        xLPost % log-posterior
        chrNumber;
        Mtot;
        annotation;
        pop;
        chrMap;
        xkPout;
        xPout;
        xPstat;
        xkPstat;
        xPsel;
        xkPsel;
        xPflat;
        xkPflat;
        Pz;
    end
    properties  (Dependent = true)
        Np; % N + 1 , where N is the number of individuals    
    end
    
    methods
        function obj = readData_ext(chromosome, x,q,r, varargin)
            if nargin>0 && numel(q) == numel(x) && numel(r) == numel(x)
                obj.chromosome = chromosome;
                obj.x = x;
                obj.q = q;
                obj.r = r;
                obj.f = q./r;
                obj.chrNumber = max(chromosome);
                obj.Mtot = numel(x);
                obj.xPstat = -Inf(obj.Mtot , 1);
                obj.xPsel = -Inf(obj.Mtot , 1);
                obj.xPflat = -Inf(obj.Mtot , 1);
                obj.xPout = -Inf(obj.Mtot , 1);
                obj.T = cell(obj.chrNumber, 1);
                obj.A = cell(obj.chrNumber, 1);
                obj.logAlpha = cell(obj.chrNumber, 1);
                obj.logBeta = cell(obj.chrNumber, 1);
                if (nargin>5)
                    obj.qual = varargin{1};
                    obj.notaRepeat = varargin{2};
                    %                     if (nargin>6)
                    %                         obj.annotation = varargin{3};
                    %                     end
                end
                % unique(obj.chromosome)
                obj = chrInds(obj);
            end
        end
        
       function obj = calcDxMin( obj )
            obj = calcDx(obj,  @(x)nanmin(x, [], 2));
        end
        
        function obj = calcDx( obj, fh )
            for cc = obj.chrNumber: -1:1
                inds = logical(cc == obj.chromosome);
                dxRaw = [NaN; diff(double(obj.x(inds)))];
                dxRaw( dxRaw < 0) = NaN;
                dxPair = [dxRaw, circshift(dxRaw,-1)];
                obj.dx(inds,1) = feval( fh, dxPair);
            end
        end
        
        function obj = unmix(obj, varargin)
            if nargin>1 && ~isempty(varargin{1})
                plotFl = varargin{1};
            else
                plotFl = '';
            end
            [obj, mu, iT, ~] = unmixRepeatsOne( obj, 'dx', plotFl,'modeNum', 2);
        end
        
        function set.pop(obj, N)
            obj.pop = population(N);
        end
        %% chromosome retrieval
        function subobj = getChromosome(obj, cc, varargin)
            if nargin>2 && any(strcmpi('old', varargin))
                subobj = chromProbO();
            else
                subobj = chromProb(); 
            end
            propNames = properties(obj);
            inds = logical(cc == obj.chromosome);
            for ii = 1:numel(propNames)
                if any(strcmpi(propNames{ii}, properties(subobj)))
                    s = size(obj.(propNames{ii}),1);
                    switch s
                        case obj.Mtot
                            subobj.(propNames{ii}) = obj.(propNames{ii})(inds, :);
                        case obj.chrNumber
                            subobj.(propNames{ii}) = obj.(propNames{ii})(cc, :);
                        otherwise
                            subobj.(propNames{ii}) = obj.(propNames{ii});
                    end
                end
            end
            subobj.M = sum(inds);
        end
        %% Np: number of individuals + 1
        function Np = get.Np(obj)
            Np = size(obj.E, 2);
        end
        
        %% operations on chromosomes
         function [obj, varargout] = run(obj, chr, Alpha, varargin)
             
            obj = obj.calcT(chr, Alpha);
            obj = obj.crossMatr(chr);
            obj = obj.cumMatr(chr);

            obj = obj.runFBflat(chr);
            obj = obj.runFBstat(chr);
            obj = obj.runFBselection(chr);
            if nargin>1 && any(strcmpi('plot', varargin))
                varargout{1} = figure;
                subplot(2,1,1)
                plot(obj.x(obj.ci{chr}), obj.xPstat(obj.ci{chr}), 'g-')
                hold all
                plot(obj.x(obj.ci{chr}), obj.xPout(obj.ci{chr}), 'r-')                  
                plot(obj.x(obj.ci{chr}), obj.xPflat(obj.ci{chr}), 'b-')
                legend({'stationary', 'selection', 'flat'})
                
                subplot(2,1,2)
                plot(obj.x(obj.ci{chr}), obj.xPstat(obj.ci{chr}) - obj.pop.Np - calcMarginal(obj.xPflat(obj.ci{chr})) , 'g-')
                hold all
                plot(obj.x(obj.ci{chr}), obj.xPsel(obj.ci{chr}) - obj.pop.Np - calcMarginal(obj.xPflat(obj.ci{chr})) , 'r-')
                legend({'stationary norm',  'selection norm'})
                
            elseif nargout>1
                varargout{1} = [];
            end
            obj.T{chr} = [];
            obj.A{chr} = [];
            obj.logAlpha{chr} = [];
            obj.logBeta{chr} = [];
         end
         %%
         function obj = chrInds(obj)     
             obj.ci = cell(obj.chrNumber, 1);
             for chr = 1: obj.chrNumber
             obj.ci{ chr } = (obj.chromosome == chr);
             obj.M(chr) = sum(obj.ci{chr});             
             obj.chrEnd = cumsum(obj.M);
             obj.chrSta = [0, obj.chrEnd(1:end-1)] + 1;
             end
         end
       %% emission
        function [obj, varargout] = calcEmission(obj, study, theta, lambda1, varargin)
            emissionHandle = @(q, r, study)emissionMixBetaBinomial(q, r, study, theta, lambda1);
            if nargin>4 && any(strcmpi({'special','s'}, varargin))
                [obj.Especial, obj.c] = wrapEmissionMatrix(obj.q, obj.r, study, emissionHandle, obj.contrib);
                if nargout>1
                    varargout{1} = obj.Especial;
                end
            else
                [obj.E, obj.c] = wrapEmissionMatrix(obj.q, obj.r, study, emissionHandle, obj.contrib);
            end            
        end
         %% transition
          function obj = calcT(obj, chr, Alpha)
            if isempty(obj.chrMap)
                warning('calcT:noChrMap', 'chromosome genetic map has not been supplied! \n please assign obj.chrMap = cm;\n cm.nt[M x 1];\n cm.cM[M x 1]' )
            end
            %= calculate Transition matrices
            tvect = abs(diff(Alpha * 0.01* recdistances(obj.chrMap(chr), obj.x(obj.ci{chr})))) ;
            %= calculate
            for ii = 1:(obj.M(chr)-1)
                if tvect(ii)~=0 && ~isinf(tvect(ii))
                     obj.T{chr}(:,:, ii) = expm(obj.pop.Q*tvect(ii));
                elseif  tvect(ii)==0
                     obj.T{chr}(:,:, ii) = eye(obj.pop.Np);
                elseif tvect(ii)== Inf
                     obj.T{chr}(:,:, ii) = repmat(obj.pop.xPstat, [1, obj.pop.Np]);
                end
            end
            %= sanity check
            if   any(obj.T{chr}(:)<0)
                error('transition3D_expm:TNegInput', 'T matrix has negative values!')
            end
            
         end
        %%
        function obj = cumMatr(obj, chr)
          % function obj = cumMatrSafe(obj)
            if ~isempty(obj.Np)
                
                obj.logAlpha{chr} = -inf(obj.M(chr), obj.Np);
                obj.logBeta{chr}  = -inf(obj.M(chr), obj.Np);

                %% forward
                Ac = obj.E( obj.chrEnd(chr), :)';
                obj.logAlpha{chr}(obj.M(chr), 1: obj.Np) = log10(Ac');
                
                scalePrev = 0;
                scaleA = zeros(obj.M(chr), 1);
                
                for m = (obj.M(chr) - 1):-1:1
                    Ac = obj.A{chr}(:,:, m) * (Ac * 10.^(scaleA(m+1) - scalePrev) );
                    obj.logAlpha{chr}(m, :)= log10(Ac) - scaleA(m+1);
                    scalePrev = scaleA(m + 1);
                    scaleA(m) = - max( obj.logAlpha{chr}( m, :) );
                end
                
                %% backward
                Bc = ones(1, obj.Np);
                obj.logBeta{chr}(1, 1: obj.Np) = 0;
                
                scalePrev = 0;
                scaleB = zeros(obj.M(chr)-1, 1);
                
                for m = 2:1:obj.M(chr)
                    Bc = Bc * obj.A{chr}(:,:, m-1)' * (10.^(scaleB(m-1) - scalePrev));
                    obj.logBeta{chr}(m, :) = log10(Bc) - scaleB(m-1);
                    scalePrev = scaleB(m-1);
                    scaleB(m) = - max(obj.logBeta{chr}(m, :));
                end
              
            else
                warning('cumMatrSafe:emptyNp', 'define T first!')
            end
        end
        %%
         function obj = crossMatr(obj, chr)
            if ~isempty(obj.E)
            if ~( numel(obj.T) < chr) && ~isempty(obj.T{chr})
                obj.A{chr} =  bsxfun(@times, ...
                    permute( obj.E(obj.chrSta(chr):(obj.chrEnd(chr)-1), :), [2, 3, 1] ), obj.T{chr} ) ;
            else
                error('crossMatr:emptyT', 'define transition matrix T first!');
            end
            else
                warning('crossMatr:emptyE', 'define emission matrix E first!');
            end
         end
        %% forward-backward
        function obj = runFB(obj, Pin, chr)
            if nargin<2
                obj.Pz = ones(1, obj.Np);
            else
                obj.Pz = Pin;
            end
            obj = runFBinternal(obj, chr);
        end
        
        function obj = runFBstat(obj, chr)
            obj.Pz = obj.pop.Pstat;
            obj = runFBinternal(obj, chr);
            obj.xkPstat(obj.ci{chr}, :)  = obj.xkPout(obj.ci{chr}, :) ;
            obj.xPstat(obj.ci{chr}) = obj.xPout(obj.ci{chr});% median(obj.xPout);
        end
        
        function obj = runFBflat(obj, chr)
            obj.Pz = ones(1, obj.Np)./obj.Np;
            obj = runFBinternal(obj, chr);
            obj.xkPflat(obj.ci{chr}, :)  = obj.xkPout(obj.ci{chr}, :) ;
            obj.xPflat(obj.ci{chr}) = obj.xPout(obj.ci{chr});
        end
        
        function PFF = getPoutFullFlat(obj, chr)
            if isempty(obj.xkPflat)
                obj = runFBflat(obj, chr);
            end
            PFF = obj.xkPout;
        end
        
        function obj = runFBselection(obj, chr)
            obj.Pz = zeros(1, obj.Np); obj.Pz(obj.Np) = 1;
            obj = runFBinternal(obj, chr);            
            obj.xkPsel(obj.ci{chr}, :)  = obj.xkPout(obj.ci{chr}, :) ;
            obj.xPsel(obj.ci{chr}) = obj.xPout(obj.ci{chr});  % median(obj.xPout);
        end
        
        %% FB - final step
        function obj = runFBinternal(obj, chr)
            if isempty(obj.A)|| isempty(obj.logAlpha ) || isempty(obj.logAlpha )
                obj = obj.crossMatr(chr);
                obj = obj.cumMatr(chr);
            end
            obj.xkPout(obj.ci{chr}, :) = bsxfun(@plus, (obj.logAlpha{chr} + obj.logBeta{chr}), log10(obj.Pz(:)'));
            obj.xPout(obj.ci{chr}) = calcMarginal(obj.xkPout(obj.ci{chr}, :), 2);
        end
    end
end