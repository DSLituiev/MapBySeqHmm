function [ AR, cSlctChrLp, cStatChrLp, neutralEvidenceThrNorm, normFactor, totIntChrSum ] = ...
    runPermutations(dataPath,  Alpha, ChrMap )
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here

AR = subtractBackGroundGenotype(dataPath);

AR = calcDx(AR,  @(x)nanmin(x, [], 2));
%=     find characteristic length scale for the 'correct' SNPs
%= as the mode for 'correct' SNP fraction (uses log-Gaussian mixture model)
[AR, mu ] = unmixRepeatsOne( AR, 'dx', '', 'modeNum', 2);
% [AR, mu, ~] = unmixRepeats( AR, 'dx');
%= the characteristic length scale
sigmaDx = 1*10^( max(mu.dx) );
%= calculate the smoothed SNP density (SNP sites / bp)
AR.W = calcReadDensity( AR, sigmaDx );

[AR] = unmixRepeatsTwo( AR, 'W', 'dx', '', 'modeNum', 3,...
    'peakVar1', 'max', 'peakVar2', 'max' );

%% general experimental constants:
%= number of plants:
study.N = 50;
%= number of potentially positive plants by a SNP:
study.kvect = uint32(0: 1: study.N)';
%= number of chromosomes:
study.chrnum = length(ChrMap);

%% initialization of the Calculation loop
nAlpha = numel(Alpha);
MT = numel(AR.x);
M = zeros(study.chrnum, 1);  % number of reads on the chromosome
%= log-likelihood of the chromosome to be stationary
cStatChrLp = zeros(study.chrnum, nAlpha);
%= log-likelihood of the chromosome to be under selection
cSlctChrLp = zeros(study.chrnum, nAlpha);
%= log-likelihood of the locus to be under selection (within chromosome)
AR.logPoSlct = zeros(MT , nAlpha);
AR.logPoint = zeros(MT, nAlpha);
%=

%%   Calculation cycle

for aa = permN:-1:1
    p = randperm(numel(AR.x));    
    
    for chr = 1: study.chrnum;
        ticInit = tic;
        
        [ inds, M(chr), ~, q, r,  contrib ] = recastChromosomeReads(  selectFieldIndices( AR , p) , chr );
        x = AR.x;
        
        [  AR.logPoSlct(inds, aa), cSlctChrLp(chr, aa), cStatChrLp(chr, aa),...
            ]  = ...
            estimateLikelihoodsOnChromosome( ChrMap(chr), [], [], study.N,...
            x, q, r, contrib, Alpha(aa));
        
        %== check for NaNs
        fprintf('\n')
        fprintf('\t The iterations for the chr.#\t%u\t took \t%4.2f\t s \t SNPs:\t%u \n',...
            chr, toc(ticInit), sum(inds) )
        %== Ready!
    end
end
%% no permutations:
aa = permN+1;

for chr = 1: study.chrnum;
        ticInit = tic;
        
        [ inds, M(chr), x, q, r,  contrib ] = recastChromosomeReads( AR, chr );
        
        [  AR.logPoSlct(inds, aa), cSlctChrLp(chr, aa), cStatChrLp(chr, aa),...
            ]  = ...
            estimateLikelihoodsOnChromosome( ChrMap(chr), [], [], study.N,...
            x, q, r, contrib, Alpha(aa));
        
        %== check for NaNs
        fprintf('\n')
        fprintf('\t The iterations for the chr.#\t%u\t took \t%4.2f\t s \t SNPs:\t%u \n',...
            chr, toc(ticInit), sum(inds) )
        %== Ready!
end

%%
neutralEvidenceThr =  -M*log10(study.N+1);
%
for aa = 1:numel(Alpha)
    %% Normalize internally
    [AR.xSlctLpoNC(:, aa), totIntChrSum(:, aa)] = normalizeChrInternally(AR.logPoSlct(:, aa), cSlctChrLp(:, aa), cStatChrLp(:, aa), AR.chromosome, study.chrnum);
    neutralEvidenceThrNC(:, aa) = neutralEvidenceThr - totIntChrSum(:, aa);
    
    %% Normalize externally
    normFactor(1, aa) = calcMarginal(AR.xSlctLpoNC(:, aa));
    AR.xSlctLpoNorm(:, aa)  = AR.xSlctLpoNC(:, aa) - normFactor(1, aa);
    
    neutralEvidenceThrNorm(:, aa) = neutralEvidenceThrNC(:, aa) - normFactor(1, aa);
end

cTotL = cSlctChrLp + cStatChrLp;

end