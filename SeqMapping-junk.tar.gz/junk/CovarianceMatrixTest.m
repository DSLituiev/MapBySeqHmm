% Covariance matrix test
n = 100;
dvect = [ .9, .97, 1];
d = diff(dvect);

g = exp(-d).*cosh(d);
h = exp(-d).*sinh(d);

P_XY = g(2);
P_VX = g(1)/2;
P_xY = h(2);
P_Vx = h(2)/2;
d_VY = sum(dvect(1:3));

P_VXY = prod(g(1:2))/2;
P_VxY = prod(h(1:2))/2;
P_VY = P_VXY + P_VxY;

sigma_VX = n*(P_VXY - P_XY * P_VY );
sigma2_X = n*P_XY*(1-P_XY);
sigma2_V = n*P_VY*(1-P_VY);

Sigma = [sigma2_X, sigma_VX;...
         sigma_VX, sigma2_V]
     
[~,pos]= chol(Sigma)

