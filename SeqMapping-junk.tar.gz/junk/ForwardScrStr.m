% Main script
%==== Do coverage penalty after the filtering
%==== Analyse diff(x)! -- should be Poisson

close all; clear all; clc;
dbclear if warning
tic

addpath('D:\MATLABuserfunctions\binomial');
addpath('D:\MATLABuserfunctions\mtimesx');
addpath('D:\MATLABuserfunctions\MinMaxSelection');
addpath('D:\MATLABuserfunctions\newtonraphson');
addpath('D:\MATLABuserfunctions'); savepath;
addpath('.\utilites');
addpath('.\betabinomial');

flagPlot = true;

%=       provide the reference ID, which is the name of the csv file without '.csv'
%= together with the backround genotype ID
%= known positions of the causative SNP can be also provided here for
%= further visualization
%  dataID = 'ABD159-rmdup-clipOverlap-q20-freebayes'; chr0 = 2; x0 = 17521246; % bkgrID = 'ABD241-rmdup-clipOverlap-freebayes'; 
% dataID = 'ABD173-rmdup-clipOverlap-q20-freebayes'; chr0 = 3 ; x0 = 1619248; % bkgrID = 'ABD241-rmdup-clipOverlap-q20-freebayes';


% dataID = 'HL10-rmdup-clipOverlap-q20-freebayes';  chr0 =  3 ;  x0 =  16473265;
 dataID = 'HL7_Paired-rmdup-clipOverlap-q20-freebayes'; x0 = 5672441; chr0 = 1;
% dataID = 'HL7_Paired-ngm-rmdup-clipOverlap-freebayes'; x0 = 5672441; chr0 = 1;
% dataID = 'HL7_Paired-rmdup-clipOverlap-mpileup'; x0 = 5672441; chr0 = 1;

disp(['=======  Processing data from the run ''', dataID, ''' ======='])

Alpha = 17;

dataOutID = sprintf('%s-a%u',dataID, Alpha);

mkdir(fullfile('figures', dataOutID))
%=       load the recombination map (contains positions of the markers
%= and genetic distance in cM between them)
load ChrMap
%= construct the path to the (primary experimental) data file
dataPath = fullfile('data', [dataID, '-ems-annotation-repfilt.csv'] );
%= extract the refenece reads if the reference ID is given:
% if exist( 'bkgrID', 'var' )
%     refPath = fullfile('data', [bkgrID, '-ems-annotation-repfilt.csv'] );
%     [AR, annotation] = subtractBackGroundGenotype(dataPath, refPath);
% else
    [AR, annotation] = subtractBackGroundGenotype(dataPath);
% end
fprintf('%4u reads\n', numel(AR.x))

if ~isempty(fieldnames(annotation))
    visualizeAnnotationStat(annotation)
    [AR.logPrior, AR.maxHitGene, AR.maxHitEffect,...
        AR.positionCDS, AR.effectAA, AR.effectCodone] = constructPriorStr(annotation);
end
% clear annotation

% clc; for ii = 70:170; fprintf('ii = %2u\n', ii); disp(AR.ann(ii).eff); end
%% crucial filtering parameters:
%== read number margins
filt.q_min = 0;
filt.r_up_quantile =  1;
filt.qual_thr = 10;
filt.f_max  = 1;
%%

% analyseHighReadNumber( AR )

% analyseReadNumVsFreqDistribution( AR)
% figure; hist(log10(RR.dx), 30)
[ obj ] = analyseReadNumberDistribution( AR.r, 'modeNum',1 );
%
% [ obj ] = analyseReadNumberDistribution( AR.q, 'modeNum',3 );
% [ obj ] = analyseReadNumberDistribution( double(AR.r) - double(AR.q), 'modeNum',3 );

%= calculate the mean distance to the two neighbouring loci for each locus
AR = calcDx(AR,  @(x)nanmin(x, [], 2));
%=     find characteristic length scale for the 'correct' SNPs
%= as the mode for 'correct' SNP fraction (uses log-Gaussian mixture model)
[AR, mu, ~, mixtObj, fH] = unmixRepeatsOne( AR, 'dx', 'plot',  'modeNum', 2);
fig(fH(4))
exportF(flagPlot, gcf, fullfile('figures',dataOutID, 'Histogram_log_dx_mixture'), 'format','eps', 'color', 'rgb')
fig(fH(3) , 'width', 30 ,'height', 18 )
exportF(flagPlot, gcf, fullfile('figures',dataOutID, 'Scatter_log_dx_log_r'), 'format','eps', 'color', 'rgb')
% close(fH(1:3))

% [AR, mu, ~] = unmixRepeats( AR, 'dx');
%= the characteristic length scale
sigmaDx = 1*10^( max(mu.dx) );
%= calculate the smoothed SNP density (SNP sites / bp)
AR.W = calcReadDensity( AR, sigmaDx );
nDx = numel(AR.dx);

figure('name','log(dx)'); 
[yh, xh]  = hist(log10(AR.dx), 30 );
barstairs(xh, yh./nDx , 'b')
xlabel('log_{10}d\itx')
set(gca, 'ylim', [0, max([yh(:)./nDx; 0.1])] )
exportF(flagPlot, gcf, fullfile('figures', dataOutID, 'Histogram_dx'), 'format','eps', 'color', 'rgb')
% 
% figure
% barstairs(xh, yh./sum(yh) , 'b')
% hold all
% [yhW, xhW]  = hist(log10(AR.W), xh );
% barstairs(xhW, yhW./nDx, 'g' , 'faceColor', 'none', 'linewidth', 3);
% xlabel('log_{10}d\itx')
% set(gca, 'ylim', [0, max([yh(:)./nDx; yhW(:)./nDx; 0.25-0.01])+0.01] )
% fig(gcf)
% exportF(flagPlot, gcf, fullfile('figures', dataID, 'Histogram_dx_W'), 'format','eps', 'color', 'rgb')

 
% yMax = log10(max( [AR.W; AR.dx]) );
% figure('name','inverse density and dx')
% scatter(  AR.dx, AR.W,3 )
% set(gca, 'xscale', 'log', 'yscale', 'log')
% ylabel('1/density'); xlabel('dx')
% % hold on; plot(10.^[0, yMax], 10.^[ 0, yMax ] , 'k-')
% axis('equal', 10.^[0, yMax, 0, yMax ] )
% exportF( flagPlot ,gcf, fullfile('figures', dataID, 'Scatter_dx_W'), 'format','eps', 'color', 'rgb')

% figure('name','r, quality, W')
% scatter( double(AR.r), 10.^-0.1*AR.qual, 3, log10(AR.W) )
% set(gca, 'xscale', 'log', 'yscale', 'log')

% [AR, mu, ~, mixtObj] = unmixRepeatsOne( AR, 'W', 'plot',  'modeNum', 2);
    
% [AR, mu, iTrue, ~, fH] = unmixRepeatsTwo( AR,  'W', 'dx',  'plot', 'modeNum', 2,...
%     'peakVar1', 'max', 'peakVar2', 'max' );

% fig(fH(3))
% exportF(flagPlot, gcf, fullfile('figures',dataID, 'W--dx'), 'format','eps', 'color', 'rgb')

% 
% [AR, mu, iTrue] = unmixRepeats( AR, 'dx', 'plot', 'modeNum', 2,...
%     'peakVar1', 'max', 'peakVar2', 'median' );


% [ AR, xMaxChr ] = appendChromosomeX( AR );
% 
% figure('name','read number and density')
% scatter(AR.xAll, double(AR.r), 3, log10(AR.W) )
% hold on
% plot( bsxfun(@times, xMaxChr', [1,1])', bsxfun(@times, ones(5,1), [1, 1e4])' , 'k-')
% set(gca, 'yscale', 'log')

%== plot the smoothed density estimate
% markerSz = 4;
% [f, spl] = plotAllChrNt(AR, 'W', 'exp10', false, 'ylim', 10.^[ floor(log10(min(AR.W))), ceil(log10(max(AR.W)))],...
%     'plotfun',@(x,y)plot(x, y, 'MarkerEdgeColor','r', ...
%     'MarkerSize', markerSz, 'Color', 'r'),...
%     'FigName', 'Density', 'yscale', 'log' );

markerSz = 4;
[f, spl] = plotAllChrNt(AR, 'dx', 'exp10', false, 'ylim', 10.^[ floor(log10(min(AR.dx))), ceil(log10(max(AR.dx)))],...
    'plotfun',@(x,y)plot(x, y, '*-', 'MarkerEdgeColor','r', ...
    'MarkerSize', markerSz, 'Color', 'r'),...
    'FigName', 'Density', 'yscale', 'log');

%== plot the read number per locus
[f, spl] = plotAllChrNt(AR, 'r', 'exp10', false,  'ylim', [1 10.^ceil(log10(max([AR.dx(:); double(AR.r)])))],...
    'plotfun',@(x,y)plot(x,y, 'x', ...
    'MarkerEdgeColor','g',  'MarkerSize', markerSz, 'linewidth', 2, 'Color', 'g'),...
    'FigName', 'Density', 'yscale', 'log', 'OldFig', f, 'OldSP', spl );
fig(f, 'width', 30 ,'height', 20 )
exportF(flagPlot, gcf, fullfile('figures', dataOutID, 'Chr_dx_r'), 'format','eps', 'color', 'rgb')
%%
%== plot the 'contribution' (responsibility) of the true distribution in
% each read
[f, spl] = plotAllChrNt(AR, 'contrib', 'exp10', false, 'ylim', [0 1],...
    'plotfun',@(x,y)plot(x,y, '*-','MarkerEdgeColor',[0, 0.75, 0], ...
    'MarkerSize', markerSz, 'Color',[0.2, 0.9, 0.2] ),...
    'FigName', 'Contribution', 'yscale', 'lin' );

if exist( 'x0', 'var')
[f, spl] = plotAllChrNt(AR, 'contrib', 'exp10', false, 'ylim', [0 1],...
    'plotfun',@(x,y)plot(x,y, 'o','MarkerEdgeColor','r', ...
    'MarkerSize', markerSz+2, 'Color', 'r'),...
    'FigName', 'Contribution', 'yscale', 'lin', ...
    'select', (AR.x == x0& AR.chromosome == chr0), 'OldFig', f, 'OldSP', spl );
end

fig(f, 'width', 30 ,'height', 20 )
exportF(flagPlot, gcf, fullfile('figures', dataOutID, 'Chr_Contrib'), 'format','eps', 'color', 'rgb')


%== discard reads in repeat regions
% [ RR ] = selectFieldIndices( AR , ~AR.notaRepeat);
% [ RR ] = selectFieldIndices( AR ,AR.notaRepeat & AR.contrib>.5 & AR.f < .65 & AR.r < 1e3 );
RR = AR;

%% filter
filt.r_max = quantile(RR.r, filt.r_up_quantile);
inds = ( RR.qual>= filt.qual_thr &...
    RR.q >= filt.q_min &...
    RR.r < filt.r_max &...
    RR.f < filt.f_max );
%= r
 RR.contrib(~inds) = 0.1;
fprintf( '% SNPs were downweighted by threshold filters\n' , sum(~inds) )
% RR.contrib = ones(size(RR.contrib));
%%
% clear AR;
clear Description
%= plot the SNP ratio
[f, spl] = plotAllChrNt(AR, 'f', 'exp10', false, 'ylim', [0 1],...
    'plotfun',@(x,y)plot(x,y, '*-', 'MarkerEdgeColor', [ 0.1, 0.75, 0.1], ...
    'MarkerSize', markerSz, 'Color', [ 0.5, 1, 0.5], 'linewidth', 2),...
    'FigName', 'SNP ratio', 'yscale', 'lin' );
for ii = 5:-1:1
    li2(ii) = line( get(spl(ii), 'xlim'), 0.5*[1, 1], 'color', [0.75, 0,  0], 'Parent', spl(ii));
    li4(ii) = line( get(spl(ii), 'xlim'), 0.25*[1, 1],  'color', 'b', 'Parent', spl(ii));
    uistack([li2(ii), li4(ii)] ,'bottom')
end

if exist( 'x0', 'var')
[f, spl] = plotAllChrNt(AR, 'f', 'exp10', false, 'ylim', [0 1],...
    'plotfun',@(x,y)plot(x,y, 'o','MarkerEdgeColor','r', ...
    'MarkerSize', markerSz+2, 'Color', 'r'),...
    'FigName', 'SNP Ratio', 'yscale', 'lin', ...
    'select', (AR.x == x0& AR.chromosome == chr0), 'OldFig', f, 'OldSP', spl );
end

fig(f, 'width', 30 ,'height', 20 )
exportF(flagPlot, gcf, fullfile('figures', dataOutID, 'Chr_SNP_Ratio'), 'format','eps', 'color', 'rgb')

%% general experimental constants:
%= number of plants:
study.N = 50;
%= number of potentially positive plants by a SNP:
study.kvect = (0: 1: study.N)';
%= potential frequencies of mutant alleles:
study.f = study.kvect./(2*study.N);
%= number of chromosomes:
study.chrnum = length(ChrMap);
%== cutoff for emission calculation
CUT_READ_NUM_BINOM = 120;
%% approximate binomial by Gaussian for high numbers
% [EmMatrix, limReads] = initializeLimEmissionMatrix(study, RR, CUT_READ_NUM_BINOM);
%% flags
flag.prior = isfield(RR, 'logPrior'); %== use prior if available

%% initialization of the Calculation loop
nX = numel(RR.x);
M = zeros(study.chrnum, 1);  % number of reads on the chromosome
%= log-likelihood of the chromosome to be stationary
cStatChrLp = zeros(study.chrnum, 1);
%= log-likelihood of the chromosome to be under selection
cSlctChrLp = zeros(study.chrnum, 1);
%= log-likelihood of the locus to be under selection (within chromosome)
RR.logPoSlct = zeros(nX, 1);
RR.logPoint = zeros(nX, 1);
%=

%%   Calculation cycle
% LL = logBetaBinomialThetaMu(k, n, mu, theta);
% theta = 0.2512;
%  theta = 0.08;

%  theta = fitBetaBinomialStat(double(AR.q(AR.contrib>0.75& AR.chromosome~=2)), double(AR.r(AR.contrib>0.75& AR.chromosome~=2)), 0.25)


% inds = true(size(AR.x)); %
inds = ( AR.chromosome~=chr0); %
% inds = (AR.contrib>0.5)& ( AR.chromosome~= chr0); %

[theta, lambda1, ~] = runSimpleEM_BetaBinomAndUniform(double(AR.q(inds)),...
    double(AR.r(inds)), study.N, 'v',...
    'contribution', AR.contrib ,'errTol', 1e-6);% , 'contribution', AR.contrib);
 
% theta = 0.08;
% lambda1 = 0.9;

clear inds 

figure
stairs(study.kvect, 10.^logBetaBinomialThetaMu0( double(study.kvect), study.N, 0.25, theta)' );

emissionHandle = @(q, r, study)emissionMixBetaBinomial(q, r, study, theta, lambda1);
%  emissionHandle = @(q, r, study)emissionBetaBinomial(q, r, study, theta);
% emissionHandle = @(qq, rr, ff)emissionk0(qq, rr, study);
[RR.E, RR.c] = wrapEmissionMatrix(RR.q, RR.r, study, emissionHandle, RR.contrib);

% [PobsNU, Mi] = likelihoodNonUniformEmission(RR.E, study.N, RR.chromosome);
% PobsN =  -Mi*log10(study.N);
% Marg = calcMarginal([PobsNU, PobsN],2 );
% calcMarginal([PobsNU, -PobsNU],2)

for chr = 1: study.chrnum;
    ticInit = tic;
    [ inds, M(chr), x, E, contrib ] = recastChromosomeReads( RR, chr );
    
    [ RR.logPoSlct(inds), cSlctChrLp(chr), cStatChrLp(chr), Ts{chr}, taus{chr} ]  = ...
        estimateLikelihoodsOnChromosome( ChrMap(chr), study.N,...
        x, E, contrib, Alpha);
    %== check for NaNs
    fprintf('\t The iterations for the chr.#\t%u\t took \t%4.2f\t s \t SNPs:\t%u \n', chr, toc(ticInit), sum(inds) )
    %== Ready!
end


RR.logPoint = log10(RR.E(:, end));
if ~exist( 'chr0', 'var'); chr0 = 1; end
% figure; surf( double(RR.x(RR.chromosome== chr0))*1e-6, 0:50, Es{chr0}, 'linestyle', 'none'); view(0,90)
X = repmat(double(RR.x(RR.chromosome== chr0))*1e-6, [1 , (study.N+1)]);
Y = repmat( 0:study.N, [ sum(RR.chromosome== chr0), 1] );
E1 = RR.E(RR.chromosome== chr0,:);
figure; 
scatter3( X(:), Y(:), (E1(:)), 10, (E1(:)), 'o', 'filled');
view(0, 90)
whitebg(gcf, 'k')
% set(gca, 'clim', [-3,0])
clear X Y 
 
% figure
% plot(Es{chr0}(:, 29))
 
neutralEvidenceThr =  -M*log10(study.N+1);
%
% % RR.slctChrLogProb = slctChrLogProb;
% RR.logPoSlctCorr = RR.logPoSlct + log10(RR.contrib);
%
% RR.logPoSlctCorrLOD = addProbChromosome(RR.logPoSlctCorr , RR.chromosome, -slctChrLogProb);
% % figure; hist(RR.logPoSlctCorrLOD(~isinf(RR.logPoSlctCorrLOD)), 30)
% %% plot without normalization
% %= (only comparable within each chromosome)
% markerSz = 4;
% yLims = [floor(quantile(RR.logPoSlctCorrLOD(~isinf(RR.logPoSlctCorrLOD)), .95)), ceil(max(RR.logPoSlctCorrLOD)) ];
% plotcutoff = yLims(1);
%
% [f, spl] = plotAllChrNt(RR, 'logPoSlctCorrLOD','exp10',false,...
%     'ylim', yLims,...
%     'plotfun',@(x,y)stem(x,y,'MarkerEdgeColor','g',  'MarkerSize', markerSz, ...
%     'Color', 'g', 'BaseValue',(plotcutoff-2)),...
%     'FigName', 'Likelihood', 'yscale', 'lin');
%
%
% for chr = 1:numel(spl)
%     line(get(spl(chr), 'xlim'), ( neutralEvidenceThr(chr) -slctChrLogProb(chr) )*[1,1],  'parent', spl(chr))
% end
%
% return
% RR.logPoSlct = RR.logPoSlct + RR.logPoint;
%% Normalize internally
[RR.xSlctLpoNC, totIntChrSum] = normalizeChrInternally(RR.logPoSlct+RR.logPoint, cSlctChrLp, cStatChrLp, RR. chromosome, study.chrnum);
neutralEvidenceThrNC = neutralEvidenceThr - totIntChrSum;dataPath, varargin

%% Normalize externally
normFactor = calcMarginal(RR.xSlctLpoNC);
RR.xSlctLpoNorm  = RR.xSlctLpoNC - normFactor;

neutralEvidenceThrNorm = neutralEvidenceThrNC - normFactor;
% thisSelLogProb(chr) = selChrLogProb(chr)

%% plot the likelihood
markerSz = 4;
[yLims, plotcutoff]  = adaptiveLims(RR.xSlctLpoNorm, 0.8);
%== not normalized !!!! (only comparable within each chromosome)


[f, spl] = plotAllChrNt(RR, 'xSlctLpoNorm','exp10',false,'ylim',[plotcutoff 0],...
    'plotfun',@(x,y)stem(x,y,'MarkerEdgeColor','g',  'MarkerSize', markerSz, ...
    'Color', 'g', 'BaseValue',(plotcutoff-2)),...
    'FigName', 'Likelihood', 'yscale', 'lin');

if isfield(RR, 'logPrior')
    z = calcMarginal(RR.xSlctLpoNC + RR.logPrior);
    RR.logPost  = RR.xSlctLpoNC + RR.logPrior - z;
%     [yLims, plotcutoff]  = adaptiveLims(RR.logPost(RR.logPost>RR.xSlctLpoNorm), 0.5);
    %     RR.logPrior = multiplyAndNormalizeLogProbEachChr(  RR.logPrior, 0, RR.chromosome );
    %     RR.logPost  = multiplyAndNormalizeLogProbEachChr( RR.xSlctLpoNorm, RR.logPrior, RR.chromosome, statChrLogProb );
    RR.logPost  = RR.logPost  - calcMarginal(RR.logPost);
    %     figure
    %     plot(RR.logPost  -  RR.logPoSlct)
    [fn, spln] = plotAllChrNt(RR, 'logPost','exp10',false,'ylim',[plotcutoff 0],...
        'plotfun',@(x,y)stem(x,y,'MarkerEdgeColor','b',  'MarkerSize', markerSz,...
        'Color', 'b', 'BaseValue',(plotcutoff-2)),...
        'FigName', 'Likelihood', 'yscale', 'lin',...
        'OldFig', f, 'OldSp', spl  );
    
    for ii = numel(spl):-1:1
        v = get(spl(ii),'Children');
        % v = allchild(spl(ii));
        set(spl(ii),'Children',flipud(v))
    end
    
end
for chr = 1:numel(spl)
    line(get(spl(chr), 'xlim'), ( neutralEvidenceThrNorm(chr)  )*[1,1],  'parent', spl(chr))
end

if exist( 'x0', 'var')
    if isfield(RR, 'logPrior')
        [f, spl] = plotAllChrNt(RR, 'logPost','exp10',false,'ylim',[plotcutoff 0],...
            'plotfun',@(x,y)stem(x,y,'MarkerEdgeColor', 'r',  'MarkerSize', markerSz+2, ...
            'BaseValue',(plotcutoff-2)),...
            'FigName', 'Likelihood', 'yscale', 'lin',...
            'OldFig', f, 'OldSp', spl,...
            'select', (RR.x == x0& RR.chromosome == chr0) );
    else
        [f, spl] = plotAllChrNt(RR, 'xSlctLpoNorm','exp10',false,'ylim',[plotcutoff 0],...
            'plotfun',@(x,y)stem(x,y,'MarkerEdgeColor', 'r',  'MarkerSize', markerSz+2, ...
            'BaseValue',(plotcutoff-2)),...
            'FigName', 'Likelihood', 'yscale', 'lin',...
            'OldFig', f, 'OldSp', spl,...
            'select', (RR.x == x0& RR.chromosome == chr0) );
    end
end

axis(spl);
fig(f, 'width', 30 ,'height', 20 )
exportfig(gcf, fullfile('figures',dataOutID, ['Chromosomes-', 'Probabilities']), 'format','eps', 'color', 'rgb')

%% analyse informativity
indsCoding = ~cellfun(@isempty, RR.effectAA);
infoPrior = log2(sum(indsCoding) );
infoPost = infoLog10(RR.logPost(indsCoding));
fprintf( 'entropy of posterior for coding-sequence variants: %4.3f bit\n', infoPost )
fprintf( 'entropy of un-rated coding-sequence variants: %4.3f bit\n', infoPrior  )
fprintf( 'information gain: %4.3f bit\n', infoPrior - infoPost  )

% infoLog10(log10(double(indsCoding(indsCoding))))
%% print a report
% fNames = fieldnames(ValidChrReads);
[ RResults ] = selectFieldIndices( RR , RR.logPrior > median(RR.logPrior) );
fNames = {'maxHitGene', 'logPoSlct', 'f', 'r',...
    'maxHitEffect','positionCDS','effectAA','effectCodone'};
dispTopHits(RResults, 'logPost', ['./figures/',dataOutID, '-tophits.txt'],'cutoff',-5,...
    'fields',fNames, 'sort', true);
