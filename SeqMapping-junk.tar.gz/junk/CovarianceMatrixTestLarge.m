% large cov. matr. test

close all; clear all; %clc;

load chr_data
load Data_xrq_1

clear DataText;
x = Dataxrq(:,1);  clear Dataxrq RawDescript
chr = 1;
dvect = interp_d_x(ChrData, chr,x);
% dvect = dvect(1:end/2);
clear ChrData chr x
N = size(dvect,1);
n = 50;
tic
[Sigma3,Mu]= assemble_covmatr_3D(dvect,n,N);
toc
SLR = splitcovmat(Sigma3); clear Sigma3
load MLEk
%MLEk = MLEk'; save('MLEk','MLEk')
kk_ind = 18;
y = zeros(N,1);
tic
for kk_ind = 2:N-1
    % if ~isempty(SLR{kk_ind,1})
    y(kk_ind) = ...
        logmvnpdf( MLEk(1:kk_ind-1), Mu(1:kk_ind-1,kk_ind), SLR{kk_ind,1})+...
        logmvnpdf( MLEk(kk_ind+1:N), Mu(kk_ind+1:N,kk_ind), SLR{kk_ind,2});
    % end
end
kk_ind = 1;
y(1) =  logmvnpdf( MLEk(kk_ind+1:N), Mu(kk_ind+1:N,kk_ind), SLR{kk_ind,2});
kk_ind = N;
y(N) =  logmvnpdf( MLEk(1:kk_ind-1), Mu(1:kk_ind-1,kk_ind), SLR{kk_ind,1});
toc
figure; plot((1:1:N)',y)
[~,maxyi] = max(y)