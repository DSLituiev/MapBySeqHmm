function dispTopHits(ChrReads, name, filpathename, varargin)
% prints top hits in a text file
%

fid = fopen(filpathename,'w+');


ChrNumber = length(ChrReads);

%% check the input parameters
p = inputParser;

addRequired(p, 'ChrReads',@isstruct);
addRequired(p,     'name', @ischar);
addParamValue(p,    'exp10',    false, @isscalar);
addParamValue(p,     'ParamName',      '',  @ischar);
addParamValue(p,   'cutoff',       [],  @isnumeric);
addParamValue(p,   'sort',       false,  @islogical);



addParamValue(p,   'fields',       {''},  @iscell);

% addParamValue(p,   'fieldsPrior',       {''},  @iscell);

parse(p, ChrReads, name, varargin{:});
if isempty(p.Results.cutoff)
    cutoff = 1e-3;
else
    cutoff = p.Results.cutoff;
end

fields = cell(length(p.Results.fields),1);
for ii = 1:length(p.Results.fields)
    fields(ii) = textscan( p.Results.fields{ii} ,'%s','Delimiter','.');
end
% value = getfield(toplevel,fields{1}{:})

fprintf(fid, ['==== Report on the ', p.Results.name, ' ==== \r\n'] );

%% disp
if isempty(p.Results.ParamName)
    String = strcat('chromosome\t','position (nt)\t', p.Results.name);
    fprintf(fid, String);
    if ~any(cellfun(@isempty, p.Results.fields))
        for nn = 1:length(p.Results.fields)
            fprintf(fid,  ['\t', fields{nn}{end}] );
        end
    end
    fprintf(fid,   '\r\n');
else
    String = strcat('chromosome\t','position (nt)\t', p.Results.ParamName);
    fprintf(fid, String);
    if ~any(cellfun(@isempty, p.Results.fields))
        for nn = 1:length(p.Results.fields)
            fprintf(fid,  ['\t', fields{nn}{end}] );
        end
    end
    fprintf(fid,   '\r\n');
end

%== define the output formatting
OutFormat = p.Results.fields;
OutFormat(:) = {'\t%5.4f'};
for nn = 1:length(p.Results.fields)
    currField  = getfield(ChrReads, fields{nn}{:});
    if iscell(currField)
        if any(cellfun(@ischar, currField))
            OutFormat{nn} = '\t %s';
        end
        if all(cellfun(@(x)( isfloat(x)| isempty(x)) , currField))
            OutFormat{nn} = '\t %f';
            currField(cellfun(@(x)( isempty(x))) ) = NaN;
            ChrReads(fields{nn}{:}) = cell2mat(currField);
        end
        if all(cellfun(@(x)( isinteger(x)| isempty(x)) , currField))
            OutFormat{nn} = '\t %u';
            a0 = currField(find(cellfun(@(x)( isinteger(x)), currField), 1, 'first'));
            currField( cellfun(@(x)( isempty(x)), currField) ) = { a0{:}*0 };
            ChrReads.(fields{nn}{:}) = cell2mat(currField);
        end
    end
    if isinteger( currField ) || islogical( getfield(ChrReads(1), fields{nn}{:}) ) % isinteger(ChrReads(1).(p.Results.fields{nn}))
        OutFormat{nn} = '\t%u';
    end
    if ischar( currField )
        OutFormat{nn} = '\t %s';
    end
end

LogInds = logical( ChrReads.(name) > cutoff );
TopInds = find(LogInds);
if p.Results.sort
    [~, sTopIndInd] = sort(ChrReads.(name)(LogInds), 'descend' );
    TopInds = TopInds(sTopIndInd);
end
S.type='()';
S.subs{2} = ':';

for ii = 1:length(TopInds)
    S.subs{1} = TopInds(ii);
    fprintf(fid,        '%u', ChrReads.chromosome(TopInds(ii)));
    fprintf(fid,     '\t%9.0u', ChrReads.x(TopInds(ii)) );
    fprintf(fid,   '\t%5.4f', ChrReads.(name)(TopInds(ii)));
    if ~any(cellfun(@isempty, p.Results.fields))
        %S %  dbstop at 95 if error
        for nn = 1:length(p.Results.fields)
            entry0 = subsref( getfield(ChrReads, fields{nn}{:}), S);
            if iscell(entry0)
                fprintf(fid, OutFormat{nn}, entry0{1} ); % (TopInds(ii),:)
            else
                fprintf(fid, OutFormat{nn}, entry0 ); % (TopInds(ii),:)
            end
        end
    end
    fprintf(fid,   '\r\n');
end

fclose(fid);

