function g = ComplHaldane(d)
% computes complement Haldane's mapping function:
% g = 1 - Haldane(d); in fractions of 1.
% d -- distance in morgans (100 x cM).
g = exp(-abs(d)).*cosh(d);