function [EmMatrix, limReads] = initializeLimEmissionMatrix(study, RR, upReadLim)
% INITIALIZELIMEMISSIONMATRIX generate the emission matrix for the low read
% numbers (under the upReadLim). For higher numbers, 
% the binomial distribution will be further approximated by Gaussian.

fnames = {'q','r'};

for ii = 1:length(fnames)
    limReads.max.(fnames{ii}) = max(RR.(fnames{ii}),[],1);
    limReads.min.(fnames{ii}) = min(RR.(fnames{ii}),[],1);
end

if upReadLim
    limReads.max.q = min( limReads.max.q, uint32(upReadLim) );
    limReads.max.r = min( limReads.max.r, uint32(upReadLim) );
end

EmMatrix = initializeEmissionMatrix(limReads, study);