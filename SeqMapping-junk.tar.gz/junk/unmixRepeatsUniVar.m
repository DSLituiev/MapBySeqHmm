function unmixRepeatsUniVar(AR, varargin)

modeNum = 3;
repeateEM = 20;
obj = gmdistribution.fit(log10(AR.W), modeNum, 'Replicates', repeateEM);

dxw = .08;
[fw, xw] = hist(log10(AR.W), -.5:dxw:2); fw = fw./ sum(fw);

figure
bar(xw, fw, 'y');
hold on
plot(xw, pdf(obj, xw')* dxw , 'k-' )

for ii = 1:modeNum
    fprintf( 'mu = \t %.4f \t Sigma = \t %.4f \t mixing = \t %.4f \n', ...
        obj.mu(ii), obj.Sigma(:,:,ii), obj.PComponents(:,ii))
    plot( xw,  obj.PComponents(ii) * normpdf(xw, obj.mu(ii), sqrt(obj.Sigma(ii)) ) * dxw  )
end


%%
% [AR, mu, iTrue] = unmixRepeats( AR, 'W', 'plot' );
[~, iTrue  ] = min(obj.mu);
[~, iFalse ] = max(obj.mu);

PrTrue  = normpdf(AR.W, obj.mu(iTrue),  sqrt(obj.Sigma(iTrue)) );
PrFalse = normpdf(AR.W, obj.mu(iFalse), sqrt(obj.Sigma(iFalse)) );
Odds = PrTrue./PrFalse;
Odds(isnan(Odds)) = 0;


C_CONTR = 1/2;
B_CONTR = 0;

AR.contrib = B_CONTR + (1-B_CONTR)./(1+ C_CONTR./Odds);

AR.contrib( log10(AR.W) < obj.mu(iTrue) ) = 1;
AR.contrib( log10(AR.W) > obj.mu(iFalse) ) = B_CONTR;
%%

figure
scatter(log10(AR.W), log10(double(AR.r)), 3, AR.contrib )
xlabel('dx'); ylabel( 'r' )
axis equal
