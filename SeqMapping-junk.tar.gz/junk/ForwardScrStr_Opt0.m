% Main script
%==== Try not exclude the common reads
%==== Do coverage penalty after the filtering
%==== Analyse diff(x)! -- should be Poisson

close all; clear all; clc;
tic
addpath('.\utilites');
addpath('D:\MATLABuserfunctions\vbgm');

% addpath('C:\Users\Dmitri\Documents\MATLAB\Information_and_Statistics\H_M');

%  runID = 'ABD159'; chr0 = 2; x0 = 17521246;
 runID = 'HL7'; x0 = 5672441; chr0 = 1;
disp(['=======  Processing data from the run ''', runID, ''' ======='])
load ChrMap


dataPath = fullfile('data', [runID, '-ems-annotation-repfilt.csv'] );
[AR , ChrNumber] = readSequencingDataCsv(dataPath);

% RR = AR;
 

AR = calcDx(AR);

%%
figure
scatter( AR.f, AR.r)

figure
hist(AR.f, 50); xlim([0,1])

AR = unmixRepeats( AR, 'dx','plot' );
% RR = AR;
 [ RR ] = selectFieldIndices( AR , AR.notaRepeat);

clear AR;
clear Description

addpath('D:\MATLABuserfunctions\mtimesx');
addpath('D:\MATLABuserfunctions\MinMaxSelection');
addpath('D:\MATLABuserfunctions'); savepath;
%% general experimental constants:
%= number of plants:
study.N = 50;
%= number of potentially positive plants by a SNP:
study.kvect = uint32(0: 1: study.N)';
%= number of chromosomes:
study.chrnum = length(ChrMap);
%== Q-matrix:
% study.Q = Qmatrix(N);
%== length in Mbp
% [ChrReads(:).xMbp] = single({ChrReads(:).x})*1e-6;
%% crucial filtering parameters:
%== read number margins
filt.r_quantiles = 0.05;
filt.q_min = 3;
filt.r_max = 1e3;
%== distance on the chromosome, number of loci for which
%==          should not exceed 'filt.loc_max'
filt.dx_max = 10;
filt.loc_max = 10;
%== ratio filters
filt.maxratio = 0.6;
filt.minratio = 0.05;
%== filter out common SNPs
filt.commonreads = false;
%== cutoff for emission calculation
flag.CutReadNumberBinom = 120;

%% frequency
RR.f = double(RR.q) ./ double(RR.r);
clear sigma f spl ch
fnames = {'q','r'};


for ii = 1:length(fnames)
    limReads.max.(fnames{ii}) = max(RR.(fnames{ii}),[],1);
    limReads.min.(fnames{ii}) = min(RR.(fnames{ii}),[],1);
end

if flag.CutReadNumberBinom
    limReads.max.q = min( limReads.max.q, uint32(flag.CutReadNumberBinom) );
    limReads.max.r = min( limReads.max.r, uint32(flag.CutReadNumberBinom) );
end

EmMatrix = initializeEmissionMatrix(limReads, study);
%% flags
%= flag to cut calculation of binomial by the read number (to normal distr.):
flag.CutReadNumberBinom = true;
flag.prior = isfield(RR, 'Pr'); %== use prior if available

fprintf(['Filtering paramers: \n',...
    '\t Cutoff of %2.1f%% quantiles of read number;\n',...
    '\t Not more then %2.0f%% of mutant read frequency \n'],...
    100* filt.r_quantiles, 100* filt.maxratio)

%% filter
%===  quality
inds = ( RR.qual>=10);
RR = selectFieldIndices(RR,inds);
%%
N = study.N;
M = zeros(study.chrnum, 1);
statChrLogProb = zeros(study.chrnum, 1);
slctChrLogProb = zeros(study.chrnum, 1);
RR.logPoSlct = zeros(size(inds));

Alpha = 0.1:0.05:10;
%%   Calculation cycle
for chr = 1: study.chrnum;
    ticInit = tic;
    
    [ inds, M(chr), x, q, r,  contrib ] = recastChromosomeReads( RR(1), chr );
    
    for aa = 1:numel(Alpha)
    [  RR.logPoSlct(inds,aa), slctChrLogProb(chr, aa), statChrLogProb(chr,aa) ]  = ...
        estimateLikelihoodsOnChromosome( ChrMap(chr), EmMatrix, limReads, N,...
                              x, q, r, contrib, Alpha(aa));
    end
    %== check for NaNs
    
    fprintf('\t The iterations for the chr.#\t%u\t took \t%4.2f\t s \t SNPs:\t%u \n', chr, toc, sum(inds) )
    %== Ready!
end

for chr = 1:5
    figure('name', sprintf('chr %u', chr))
    plot(Alpha, slctChrLogProb(chr,:), 'linewidth',2 );
    hold all
    plot(Alpha, statChrLogProb(chr,:),':', 'linewidth',2 );
%     fig(gcf)
%     export_fig(sprintf('figures/alpha_chr%u', chr), '-eps')
end

chrInds = (RR.chromosome == chr0);

figure
surf(Alpha ,RR.x(chrInds), RR.logPoSlct(chrInds, :), 'linestyle', 'none')
xlabel('\alpha'); ylabel('x')


aa = 2;
figure
plot(RR.x(chrInds), RR.logPoSlct(chrInds, aa), 'linewidth',2 );
fig(gcf)

figure
plot(Alpha, RR.logPoSlct(find(RR.x == x0),: ), 'linewidth',2 );
fig(gcf)
% export_fig(sprintf('figures/alpha_true', chr), '-eps')


% clear EmMatrix
%% calculate P(other chrs are stationary)
I = logical(eye(study.chrnum));
othersStatLogProb = zeros(study.chrnum, 1);
thisSelLogProb = zeros(study.chrnum, 1);
RR.logPoSlctNC = zeros(size(RR.logPoSlct));

for chr = study.chrnum:-1:1
    othersStatLogProb(chr) = sum( statChrLogProb(~I(:,chr)) );    
    inds = (RR.chromosome == chr);
    RR.logPoSlct(inds) = RR.logPoSlct(inds) + othersStatLogProb(chr);

    RR.logPoSlctNC(inds) =  RR.logPoSlct(inds) -  calcMarginal(RR.logPoSlct(inds));
%     marg(chr) =  calcMarginal(ObservationReads.logPobsSelection(inds)) ;    
    
end
%== dot product:
normFactor = calcMarginal(slctChrLogProb + othersStatLogProb); 

RR.logPobsSelectionNorm  = RR.logPoSlct - normFactor;
% thisSelLogProb(chr) = selChrLogProb(chr)

%% plot the likelihood
markerSz = 4;
plotcutoff = -30;
[f, spl] = plotAllChrNt(RR, 'logPoSlctNC','exp10',false,'ylim',[plotcutoff 0],...
        'plotfun',@(x,y)stem(x,y,'MarkerEdgeColor','g',  'MarkerSize', markerSz, 'Color', 'g', 'BaseValue',(plotcutoff-2)),...
        'FigName', 'Likelihood', 'yscale', 'lin' );
    
%     [f, spl] = plotAllChrNt(ObservationReads, 'logPobsSelection','exp10',true,'ylim',10.^[plotcutoff 0],...
%         'plotfun',@(x,y)stem(x,y,'MarkerEdgeColor','g',  'MarkerSize', markerSz, 'Color', 'g', 'BaseValue',10^(plotcutoff-2)),...
%         'FigName', 'Likelihood');
%     

return
%% plot
% figure
%     
% for chr = 1:study.chrnum    
%     inds = (RR.chromosome == chr);
%     subplot(study.chrnum, 1, chr)
%     plot(RR.x(inds), RR.logPobsSelectionNC(inds))
%     hold all
% %     plot(ObservationReads.x(inds), 1e1*(ObservationReads.f(inds) - 1), 'r');    
% %     stem(ObservationReads.x(inds), ObservationReads.logPobsSelection(inds) - selChrLogProb(chr), 'BaseValue', -1e10)
% %       ylim( -1e1*[2 0])
% end

% othersStatLogProb-calcMarginal(othersStatLogProb)
%== note correlation
% figure; plot(1:5, [M, othersStatLogProb])

%% a small cycle for prior probabilities:
if flag.prior    %== if prior data is available, calculate the prior
    for chr = 1: study.chrnum;
        ObservationReads(chr).logPrior = log10(double(ConstructPriorStr2( ObservationReads(chr).Pr )));
    end
else            %== if no prior data is available, assign uniform prior
    for chr = 1: study.chrnum;
        ObservationReads(chr).logPrior = -log10(ObservationReads(chr).M).*ones( ObservationReads(chr).M,  1 );
    end
end

clear logAcum logBcum chr
%% Normalization
[ObservationReads, logPchr] = ChrNormalization2(ObservationReads);
fprintf('chr %u\tlogP\t%u\n',[(1:5); logPchr'])
markerSz = 4;
plotcutoff = -8;
if flag.prior
    %% plot the Prior
    [f, spl] = plotAllChrNt(ObservationReads, 'logPrior','exp10',true,'ylim',10.^[plotcutoff 0],...
        'plotfun',@(x,y)stem(x,y,'MarkerEdgeColor','y', 'MarkerSize', markerSz, 'Color', 'y', 'BaseValue',10^(plotcutoff-2)),...
        'FigName','Posterior + Prior');
    %% plot the likelihood
    [f, spl] = plotAllChrNt(ObservationReads, 'logPobsN','exp10',true,'ylim',10.^[plotcutoff 0],...
        'plotfun',@(x,y)stem(x,y,'MarkerEdgeColor','g',  'MarkerSize', markerSz, 'Color', 'g', 'BaseValue',10^(plotcutoff-2)),...
        'FigName','Likelihood', ...
        'OldSP', spl, 'OldFig', f);
else
    %% plot the likelihood
    [f, spl] = plotAllChrNt(ObservationReads, 'logPobsN','exp10',true,'ylim',10.^[plotcutoff 0],...
        'plotfun',@(x,y)stem(x,y,'MarkerEdgeColor','g',  'MarkerSize', markerSz, 'Color', 'g', 'BaseValue',10^(plotcutoff-2)),...
        'FigName','Likelihood');
end


%% Apply the Bayes formula (if prior is available)
if flag.prior
    ObservationReads = bayesLogProb(ObservationReads);
    %== plot the Posterior ...
    [f, spl] = plotAllChrNt(ObservationReads, 'logPost','exp10',true,'ylim',10.^[plotcutoff 0],...
        'plotfun',@(x,y)stem(x,y,'MarkerEdgeColor','r', 'Marker', 'x', 'MarkerSize', 3, ...
        'Color', 'r', 'linestyle',':', 'BaseValue',10^(plotcutoff-2)),...
        'OldSP', spl, 'OldFig', f);
    leg = legend({'prior','likelihood','posterior'});
    set(spl,'box','on')
end

fig(gcf,'width',12,'height',12)
calcSetLegpos(spl, leg)
set(leg, 'box', 'off')
exportfig(gcf, 'Chromosomes', 'format','eps', 'color', 'rgb')
%% print a report
% fNames = fieldnames(ValidChrReads);
fNames = { 'logPrior', 'logPobsN', 'AT', 'f','q', 'r', 'Pr.STOP_GAINED','Pr.NON_SYNONYMOUS_CODING','Pr.ESSENTIAL_SPLICE_SITE','Pr.INTRONIC'};
disptophits(ObservationReads, 'logPost', 'tophits.txt','cutoff',-2,...
    'fields',fNames, 'sort', true);

fNames = { 'logPost', 'logPobsN', 'AT','f','q','r', 'Alleles.Ref', 'Alleles.Alt',...
    'Pr.STOP_GAINED','Pr.NON_SYNONYMOUS_CODING', 'Pr.ESSENTIAL_SPLICE_SITE'};

disptophits(ObservationReads, 'logPrior', 'tophitsPrior.txt','cutoff',-2,...
    'fields',fNames, 'sort', true);