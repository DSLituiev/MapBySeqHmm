% Main script
%==== Do coverage penalty after the filtering
%==== Analyse diff(x)! -- should be Poisson

close all; clear all; clc; % dbclear all
tic
addpath('D:\MATLABuserfunctions\mtimesx');
addpath('D:\MATLABuserfunctions\MinMaxSelection');
addpath('D:\MATLABuserfunctions'); savepath;
addpath('.\utilites');

%=       provide the reference ID, which is the name of the csv file without '.csv'
%= together with the backround genotype ID
%= known positions of the causative SNP can be also provided here for
%= further visualization
% dataID = 'ABD159-rmdup-clipOverlap-freebayes'; bkgrID = 'ABD241-rmdup-clipOverlap-freebayes'; chr0 = 2; x0 = 17521246;
% dataID = 'ABD173-rmdup-clipOverlap-freebayes'; bkgrID = 'ABD241-rmdup-clipOverlap-freebayes';

%  dataID = 'HL10';
dataID = 'HL7_Paired-rmdup-clipOverlap-freebayes'; x0 = 5672441; chr0 = 1;
disp(['=======  Processing data from the run ''', dataID, ''' ======='])
%=       load the recombination map (contains positions of the markers
%= and genetic distance in cM between them)
load ChrMap
%= construct the path to the (primary experimental) data file
dataPath = fullfile('data', [dataID, '-ems-annotation-repfilt.csv'] );
%= extract the refenece reads if the reference ID is given:
if exist( 'bkgrID', 'var' )
    refPath = fullfile('data', [bkgrID, '-ems-annotation-repfilt.csv'] );
    [AR, annotation] = subtractBackGroundGenotype(dataPath, refPath);
else
    [AR, annotation] = subtractBackGroundGenotype(dataPath);
end

if ~isempty(fieldnames(annotation))
    visualizeAnnotationStat(annotation)
    [AR.logPrior, AR.maxHitGene, AR.maxHitEffect,...
        AR.positionCDS, AR.effectAA, AR.effectCodone] = constructPriorStr(annotation);
end
% clear annotation

% clc; for ii = 70:170; fprintf('ii = %2u\n', ii); disp(AR.ann(ii).eff); end
%% crucial filtering parameters:
%== read number margins
filt.q_min = 3;
filt.r_up_quantile =  0.95;
filt.qual_thr = 10;
filt.f_max  = .75;
%%

% analyseHighReadNumber( AR )

% analyseReadNumVsFreqDistribution( AR)

% [ obj ] = analyseReadNumberDistribution( AR.r, 'modeNum',3 );

% [ obj ] = analyseReadNumberDistribution( AR.q, 'modeNum',3 );

% [ obj ] = analyseReadNumberDistribution( double(AR.r) - double(AR.q), 'modeNum',3 );

%= calculate the mean distance to the two neighbouring loci for each locus
AR = calcDx(AR);
%=     find characteristic length scale for the 'correct' SNPs
%= as the mode for 'correct' SNP fraction (uses log-Gaussian mixture model)
% [AR, mu, ~] = unmixRepeats( AR, 'dx', 'plot' );
[AR, mu, ~] = unmixRepeats( AR, 'dx');
%= the characteristic length scale
sigmaDx = 2*10^max(mu.dx);
%= calculate the smoothed SNP density (SNP sites / bp)
AR.W = calcReadDensity( AR.x, sigmaDx );

[AR, mu, iTrue] = unmixRepeats( AR, 'W', 'plot', 'modeNum', 3,...
    'peakVar1', 'min', 'peakVar2', 'median' );
% RR = selectFieldIndices(RR, inds);
%== plot the smoothed density estimate
markerSz = 4;
[f, spl] = plotAllChrNt(AR, 'W', 'exp10', true, 'ylim', 10.^[0 20],...
    'plotfun',@(x,y)plot(x,y,'MarkerEdgeColor','r', ...
    'MarkerSize', markerSz, 'Color', 'r'),...
    'FigName', 'Density', 'yscale', 'log' );

%== plot the read number per locus
[f, spl] = plotAllChrNt(AR, 'r', 'exp10', true,...
    'plotfun',@(x,y)plot(x,y, 'x', ...
    'MarkerEdgeColor','g',  'MarkerSize', markerSz, 'Color', 'g'),...
    'FigName', 'Density', 'yscale', 'log', 'OldFig', f, 'OldSP', spl );

%%
%== plot the 'contribution' (responsibility) of the true distribution in
% each read
[f, spl] = plotAllChrNt(AR, 'contrib', 'exp10', false, 'ylim', [0 1],...
    'plotfun',@(x,y)plot(x,y,'MarkerEdgeColor','r', ...
    'MarkerSize', markerSz, 'Color', 'r'),...
    'FigName', 'Contribution', 'yscale', 'lin' );

%== discard reads in repeat regions
% [ RR ] = selectFieldIndices( AR , ~AR.notaRepeat);
% [ RR ] = selectFieldIndices( AR ,AR.notaRepeat & AR.contrib>.2 & AR.f < .65 & AR.r < 1e3 );
RR = AR;

%% filter
filt.r_max = quantile(RR.r, filt.r_up_quantile);
inds = ( RR.qual>=10 &...
    RR.q >= filt.q_min &...
    RR.r < filt.r_max &...
    RR.f < filt.f_max );
%= r
RR.contrib(~inds) = 0.1;
 clear Description

%% general experimental constants:
%= number of plants:
study.N = 50;
%= number of potentially positive plants by a SNP:
study.kvect = uint32(0: 1: study.N)';
%= number of chromosomes:
study.chrnum = length(ChrMap);
%== cutoff for emission calculation
CUT_READ_NUM_BINOM = 120;
%% flags
flag.prior = isfield(RR, 'logPrior'); %== use prior if available
%% permutation
permN = 100;

%% initialization of the Calculation loop
M = zeros(study.chrnum, 1);  % number of reads on the chromosome
%= log-likelihood of the chromosome to be stationary
statChrLogProb = zeros(study.chrnum, permN);
%= log-likelihood of the chromosome to be under selection
slctChrLogProb = zeros(study.chrnum, permN);

%=
Alpha = 5;

%= log-likelihood of the locus to be under selection (within chromosome)
AR.logPoSlctChr = zeros(size(inds));

load('permut.mat', 'slctChrLogProb',  'statChrLogProb', 'RR', 'AR', 'permN')

for pp = permN:-1:1
p = randperm(numel(AR.x));
 [ RR(pp) ] = selectFieldIndices( AR , p);
 RR(pp).x = AR.x;
%%
% clear AR;

%% approximate binomial by Gaussian for high numbers
[EmMatrix, limReads] = initializeLimEmissionMatrix(study, RR(pp), CUT_READ_NUM_BINOM);

%%   Calculation cycle
for chr = 1: study.chrnum;
    ticInit = tic;
    
    [ inds, M(chr), x, q, r,  contrib ] = recastChromosomeReads( RR(pp), chr );
    
    [  RR(pp).logPoSlctChr(inds), slctChrLogProb(chr,pp), statChrLogProb(chr,pp)]  = ...
        estimateLikelihoodsOnChromosome( ChrMap(chr), EmMatrix, limReads, study.N,...
        x, q, r, contrib, Alpha);
    %== check for NaNs
    
    fprintf('\t The iterations for the chr.#\t%u\t took \t%4.2f\t s \t SNPs:\t%u \n', chr, toc, sum(inds) )
    %== Ready!
end
end
pp = permN+1;
[ RR(pp) ] = AR;
%% approximate binomial by Gaussian for high numbers
[EmMatrix, limReads] = initializeLimEmissionMatrix(study, RR(pp), CUT_READ_NUM_BINOM);

%%   Calculation cycle
for chr = 1: study.chrnum;
    ticInit = tic;
    
    [ inds, M(chr), x, q, r,  contrib ] = recastChromosomeReads( RR(pp), chr );
    
    [  RR(pp).logPoSlctChr(inds), slctChrLogProb(chr,pp), statChrLogProb(chr,pp)]  = ...
        estimateLikelihoodsOnChromosome( ChrMap(chr), [], [], study.N,...
        x, q, r, contrib, Alpha);
    %== check for NaNs
    
    fprintf('\t The iterations for the chr.#\t%u\t took \t%4.2f\t s \t SNPs:\t%u \n', chr, toc, sum(inds) )
    %== Ready!
end

save('permut.mat', 'slctChrLogProb',  'statChrLogProb', 'RR', 'AR', 'permN')
cc = 2;
[yhSt, xhSt] = hist(statChrLogProb(cc, 1:end-1));
[yhSl, xhSl] = hist(slctChrLogProb(cc, 1:end-1));
figure
barstairs(xhSt ,yhSt, 'b')
hold all
bh = barstairs(xhSl ,yhSl, 'r'); alpha(bh, .4)
plot([1,1]*statChrLogProb(cc, end), get(gca, 'ylim'), 'c' )
plot([1,1]*slctChrLogProb(cc, end), get(gca, 'ylim'), 'r' )

pp = permN+2;
RR(pp) = AR;
RR(pp).logPoSlctChr = median( [RR(:).logPoSlctChr], 2 );
statChrLogProb(:, pp) = median(statChrLogProb, 2);
slctChrLogProb(:, pp) = median(slctChrLogProb, 2);
%% calculate P(other chrs are stationary)


for chr = study.chrnum:-1:1
    inds = (RR(pp).chromosome == chr);
%     RR.logPoSlctNC(inds) = RR.logPoSlctChr(inds) + normFactChr(chr);
    RR(pp).logPoSlct(inds) = RR(pp).logPoSlctChr(inds) - statChrLogProb(chr);
end

%% plot the likelihood
markerSz = 4;
plotcutoff = -20;
%== not normalized !!!! (only comparable within each chromosome)


[f, spl] = plotAllChrNt(RR(pp), 'logPoSlct','exp10',false,'ylim',plotcutoff*[1 -1],...
    'plotfun',@(x,y)stem(x,y,'MarkerEdgeColor','g',  'MarkerSize', markerSz, ...
    'Color', 'g', 'BaseValue',(0)),...
    'FigName', 'Likelihood', 'yscale', 'lin');

axis(spl);

if exist( 'x0', 'var')
    [f, spl] = plotAllChrNt(RR(pp), 'logPoSlctNC','exp10',false,'ylim',[plotcutoff 0],...
        'plotfun',@(x,y)stem(x,y,'MarkerEdgeColor','r',  'MarkerSize', markerSz, ...
        'Color', 'g', 'BaseValue',(plotcutoff-2)),...
        'FigName', 'Likelihood', 'yscale', 'lin',...
        'OldFig', f, 'OldSp', spl,...
        'select', (RR(pp).x == x0& RR(pp).chromosome == chr0) );
end
% dbclear all; 
fig(gcf,'width',24,'height',24)
% calcSetLegpos(spl, leg)
% set(leg, 'box', 'off')
exportfig(gcf, fullfile('figures',['Chromosomes-', dataID]), 'format','eps', 'color', 'rgb')

%% analyse informativity
indsCoding = ~cellfun(@isempty, RR.effectAA);
infoPrior = log2(sum(indsCoding) );
infoPost = infoLog10(RR.logPost(indsCoding));
fprintf( 'entropy of posterior for coding-sequence variants: %4.3f bit\n', infoPost )
fprintf( 'entropy of un-rated coding-sequence variants: %4.3f bit\n', infoPrior  )
fprintf( 'information gain: %4.3f bit\n', infoPrior - infoPost  )

% infoLog10(log10(double(indsCoding(indsCoding))))


%% print a report
% fNames = fieldnames(ValidChrReads);
[ RResults ] = selectFieldIndices( RR , RR.logPrior > median(RR.logPrior) );
fNames = {'maxHitGene', 'logPoSlct', 'f', 'r',...
    'maxHitEffect','positionCDS','effectAA','effectCodone'};
dispTopHits(RResults, 'logPost', ['./figures/',dataID, '-tophits.txt'],'cutoff',-5,...
    'fields',fNames, 'sort', true);
