% re-formating the data
clear all
load Data_HL7_uint32
% ChrData = cell(1,5);
for ii = 1:5
    Data_xrqExNsSt{1,ii} = Dataxrq_allHL7(Dataxrq_allHL7(:,1)==ii,[2,3,4]);
    Data_xrqExNsSt{2,ii} = ExNsSt(Dataxrq_allHL7(:,1)==ii,:);
end
clear Dataxrq_allHL7 ExNsSt ii
save DataHL7uint32cell