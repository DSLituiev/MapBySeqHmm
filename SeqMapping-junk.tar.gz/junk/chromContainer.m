classdef chromContainer < hgsetget
    properties
        chromosome = {};
        chrNumber = 1;
        sampleName
        population
    end
    properties (Dependent = true)
       M;
       Mtot;
    end
    
    methods
        
        function obj = chromContainer(sampleName, pop)
            obj.sampleName = sampleName;
            obj.population = pop;
        end
        
        function addChromosome(obj, childObj, varargin)
            if nargin>2 && isscalar(varargin)
                obj.chromosome{varargin{1}}= childObj;
                childObj.parent = obj;Less
                childObj.chromosome = varargin{1};
                if varargin{1}> obj.chrNumber
                    obj.chrNumber = double(varargin{1});
                end
            else
                obj.chromosome{end+1}= childObj;
                childObj.parent = obj;
                obj.chrNumber = obj.chrNumber+1;
            end
        end
        
        function outObj=getChild(obj, n)
            outObj = obj.chromosome{n};
        end
        
        function obj= filterBy(obj, field, fhandle)
            for cc = 1:obj.chrNumber
                 obj.chromosome{cc}.filterBy(field, fhandle);
            end
        end
        
        function Mtot = get.Mtot(obj)
            Mtot = sum(obj.M);
        end
        
        function M = get.M(obj)
            M = zeros(obj.chrNumber,1);
            for cc = 1:obj.chrNumber
                 M(cc) = obj.chromosome{cc}.M;
            end
        end
        
%         function x = get.x(obj)
%             x = getfield(obj, 'x');
%         end
        
        function out = getChrField(obj, field)
            out = zeros(obj.Mtot, 1);
            subs = cumsum([0; obj.M]);            
            for cc = 1:obj.chrNumber
                 out(subs(cc)+1:subs(cc+1)) = obj.chromosome{cc}.(field);
            end 
        end
        
        function obj = setChrField(obj, field, value);
            M = obj.M;
            subs = cumsum([0; M]);
            if numel(value)== subs(end);
                for cc = 1:obj.chrNumber
                    obj.chromosome{cc}.(field) = value(subs(cc)+1:subs(cc+1));
                end
            else
                error('wrong dimensions in the input for the field %s', field)
            end
        end
        %%
        function  varargout = plotChromosomes(obj, fields, varargin)
            p = inputParser;
            addRequired(p, 'obj',@isobject);
            addRequired(p, 'fields', @ischar);
            %
            addParamValue(p,     'exp10',             false, @isscalar);
            % addParamValue(p,     'color',                   'b');
            addParamValue(p,     'xname',                  'x',  @ischar);
            addParamValue(p,     'xlim',   0,  @isnumeric);
            addParamValue(p,   'FigName',                   '',  @ischar);
            addParamValue(p,     'OldSP',   zeros(obj.chrNumber,1),  @isnumeric);
            addParamValue(p,    'OldFig',   zeros(obj.chrNumber,1),  @isnumeric);
            addParamValue(p,    'yscale',               'log' ,  @ischar);
            addParamValue(p,    'xscale',               'lin' ,  @ischar);
            addParamValue(p,      'ylim',                   []);
            addParamValue(p, 'linestyle',                  '-',  @ischar);
            addParamValue(p,   'plotfun',                @plot,  @(x)isa(x,'function_handle'));
            addParamValue(p,    'select',                   '',  @ischar );
            addParamValue(p,   'linewidth',                1 , @isscalar);
            
            parse(p, obj, fields, varargin{:});
            
            if isempty(p.Results.FigName)
                if iscellstr(p.Results.fields)
                    if strcmp(p.Results.xname,'x')
                        FigureName = strjoin( p.Results.fields, ', ' );
                    else
                        FigureName = [ strjoin( p.Results.fields, ', ' ), ' vs ', p.Results.xname];
                    end
                elseif  ischar(p.Results.fields)
                    if strcmp(p.Results.xname,'x')
                        FigureName = p.Results.fields;
                    else
                        FigureName = [ p.Results.fields, ' vs ', p.Results.xname];
                    end
                end
            else
                FigureName = p.Results.FigName;
            end
            
            if p.Results.OldSP
                f = figure(p.Results.OldFig);
                set(f, 'name', FigureName);
                %  Params.Colors = ['b','g'];
            else
                f = figure('name', FigureName);
                % Params.Colors = ['y','r'];
            end

            maxNt = zeros(obj.chrNumber, 1);
            maxXMb = zeros(obj.chrNumber, 1);
            spl = zeros(obj.chrNumber, 1);
            lser = zeros(obj.chrNumber, 1);
            fieldName = fields;
            
            %% plot
            maxY = -Inf;
            minY = Inf;
            for chr = 1:obj.chrNumber
                
                if any(p.Results.OldSP)
                    spl(chr) =  p.Results.OldSP(chr);
                    subplot(spl(chr));
                else
                    spl(chr) = subplot(obj.chrNumber, 1, chr);
                end
                
                if isempty(p.Results.select)
                    xValues = obj.chromosome{chr}.(p.Results.xname);
                    yValues = obj.chromosome{chr}.(fieldName);
                else
                    xValues = obj.chromosome{chr}.(p.Results.xname)(p.Results.select);
                    yValues = obj.chromosome{chr}.(fieldName)(p.Results.select);
                end
                maxY = max([maxY; yValues(:)]);
                minY = min([minY; yValues(:)]);
                
                maxNt(chr) = max( xValues );
                maxXMb(chr) = single(maxNt(chr))*1e-6;
                
                if ( size(xValues) == size(yValues) )
                    lser(chr) = doplottingcurve( xValues, yValues, p );
                elseif isscalar(yValues)
                    lser(chr) = doplottingline( maxNt(chr), yValues,  p );
                else
                    warning('plotAllChr:dimmismatch','dimension mismatch between .x and the .(%s)! Nothing to plot', fieldName)
                end
                
                %                 spl(chr) = gca;
                if strcmpi(p.Results.xscale , 'lin')
                    set(spl(chr),'xlim',[ 0 , maxNt(chr) ]);
                else
                    %  set(spl(chr),'xlim',  10.^[0 , log10( double(ChrReads(chr).maxNt) ) ]);
                    set(spl(chr), 'xlim', 10.^[0, round(log10( double(maxNt(chr)) ))] )
                end
                hold on
            end
            
            set(lser, 'linewidth', p.Results.linewidth);
            
            set(spl,'yscale',p.Results.yscale);
            set(spl,'xscale',p.Results.xscale);
            
            if ~isempty(p.Results.ylim) && isnumeric(p.Results.ylim)
                yLim = p.Results.ylim;
            elseif isempty(p.Results.ylim)
                yLim = [minY, maxY];
            end
            
            if isnumeric(p.Results.ylim)
                set(spl, 'ylim', yLim);
                %    set(spl,'YTickMode','auto')
                if strcmpi(p.Results.yscale, 'log')
                    if p.Results.exp10
                        set(spl, 'ytick',...
                            10.^( (yLim(1)) : floor(diff((yLim))/2) : (yLim(2)) ) );
                    else
                        set(spl, 'ytick',...
                            10.^( log10(yLim(1)) : floor(diff(log10(yLim))/2) : log10(yLim(2)) ) );
                    end
                end
            end
            
            %% set the x-length in correspondence if ( p.Results.xname == 'x' )
            %        [left bottom width height]
            splpos = cell2mat(get(spl,'position'));
            if ~(size(p.Results.xlim,2) == 2)
                if strcmpi(p.Results.xname,'x')
                    splpos(:,3) = max(splpos(:,3)).* ([maxXMb(:)])'./max([maxXMb(:)]);
                    % elseif strcmpi(p.Results.xscale, 'lin')
                    %     splpos(:,3) = splpos(1,3).* ([ChrReads(:).maxXMb])'./max([ChrReads(:).maxXMb]);
                elseif strcmpi(p.Results.xscale, 'log')
                    % xlims = cellfun(@diff, get(spl, 'xlim'))
                    splpos(:,3) = max(splpos(:,3)).*...
                        ( log10(double(maxNt'))./ log10(double(max(maxNt))) );
                end
            end
            
            if strcmpi(p.Results.xname,'x')
                xticks = 1e6*(0:1:ceil(max(maxXMb)))';
                xticklabel =  strtrim(cellstr(num2str(1e-6 * xticks,3)));
                ind5 = logical(mod(xticks,5e6));
                xticklabel(ind5) = {''};
                
                for chr = 1:obj.chrNumber
                    % set(spl(chr), 'position', splpos(chr,:));
                    % get(spl(chr),'position')
                    set(spl(chr),'xtick',xticks(1:ceil( maxXMb(chr))),...
                        'XTickLabel', xticklabel(1:ceil( maxXMb(chr))));
                    set(spl(chr),'box','off')
                end
            end
            
            if (size(p.Results.xlim,2) == 2)
                set(spl, 'xlim', p.Results.xlim);
                for chr = 1:obj.chrNumber
                    splpos(chr,3) = max(splpos(:,3));
                    set(spl(chr), 'position', splpos(chr,:) );
                end
            else
                for chr = 1:obj.chrNumber
                    set(spl(chr), 'position', splpos(chr,:));
                end
            end
            %== define the callback function:
            dcm_obj = datacursormode(f);
            set(dcm_obj ,'UpdateFcn',{@PlotCallbackFNt,lser, obj, p.Results.xname, fieldName, p.Results.exp10});
            
            
            %% subfunctions
            function lser = doplottingcurve(xValues , yValues , p)
                if    ~p.Results.exp10
                    lser = p.Results.plotfun(xValues, yValues);
                elseif p.Results.exp10
                    lser = p.Results.plotfun( xValues, 10.^yValues);
                end
            end
            
            function lserOut = doplottingline(maxNt, yValues,  p)
                if    ~p.Results.exp10
                    lserOut =  p.Results.plotfun([0 1] .*double(maxNt), yValues .*[1 1]);
                elseif p.Results.exp10
                    lserOut =  p.Results.plotfun([0 1] .*double(maxNt), 10.^double(yValues) .*[1 1]);
                end
            end
            
            varargout = {f, spl};
        end
        %%
        function normalizeProbabilities()
            %%  normalize internally:
            %==  : find normalization factor
            totIntChrSum = calcMarginalDim( [cStatChrLp, cSlctChrLp], 2 );
            % LOD = statChrLogProb - thisSelLogProb0;
            
            %== loop 2 : normalize
            xSlctLpoNC    = -Inf(chrNum, 1);
            
            for chr = chrNum:-1:1
                inds = (chromosome == chr);
                %     RR.logPoSlctNC(inds) = RR.logPoSlct(inds) + normFactChr(chr);
                xSlctLpoNC(inds) = xSlctLpo(inds) - totIntChrSum(chr);
            end
            neutralEvidenceThrNC = neutralEvidenceThr - totIntChrSum;
            
            %% Normalize externally
            normFactor = calcMarginal(RR.xSlctLpoNC);
            RR.xSlctLpoNorm  = RR.xSlctLpoNC - normFactor;
            
            neutralEvidenceThrNorm = neutralEvidenceThrNC - normFactor;
        end
    end
end