function Pqrk = initializeEmissionMatrix(mins, maxs, study)
% initializes binomial conditional probability array P[q|r,k]
%
%%%%%%%%%   input:   %%%%%%%%%%%%%%%%%%%
% n -- number of plants;
%
% mins:
% mins.r, mins.q
% maxs:
%  maxs.r, maxs.q
%
% mins.r -- minimum number of reads:
% maxs.r -- maximum number of reads:
% mins.q -- min number of positive reads:
% maxs.q -- max number of positive reads:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% use the obtained array as:
% Pfrq( q0 - mins.q + 1 , r0 - mins.r + 1, k0 + 1 )
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%= number of potentially positive plants by a SNP: study.kvect
%= number of reads
r = mins.r : 1 : maxs.r;
%= number of positive reads:
q = mins.q : 1 : maxs.q;

[rr,qq,ff] = ndgrid(double(r), double(q), double(study.kvect)./double(2*study.N) );
% Format = 'double';
Pqrk = binopdf(qq, rr, ff);
