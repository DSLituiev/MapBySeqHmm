% global comparison of several HTS data to find out background mutations
clc
clear all
DSetA = load('datafiles\ChrReads_HL7.mat');
DSetB = load('datafiles\ChrReads_AB1.mat');
ChrNumber = 5;

for chr = 1:ChrNumber
    TempRef = DSetB.ChrReads(chr).Alleles.Ref;
    TempAlt = DSetB.ChrReads(chr).Alleles.Alt;
    
    DSetB.ChrReads(chr).Alleles = rmfield(DSetB.ChrReads(chr).Alleles,'Alt');
    DSetB.ChrReads(chr).Alleles = rmfield(DSetB.ChrReads(chr).Alleles,'Ref');
    
    SNPindRef = ( cellfun(@(x)size(x,2), TempRef )==1) ;
    SNPindAlt = ( cellfun(@(x)size(x,2), TempAlt )==1) ;
    
    DSetB.ChrReads(chr).Alleles.Ref = char(zeros(length(DSetB.ChrReads(chr).x),1));
    DSetB.ChrReads(chr).Alleles.Alt = char(zeros(length(DSetB.ChrReads(chr).x),1));
    
    DSetB.ChrReads(chr).Alleles.Ref(SNPindRef) = char(TempRef(SNPindRef));
    DSetB.ChrReads(chr).Alleles.Alt(SNPindAlt) = char(TempAlt(SNPindAlt));
end

CommonReads(chr).x = [];
for chr = 1:ChrNumber
    [CommonReads(chr).x, CommonReads(chr).iB, CommonReads(chr).iA] ...
        = intersect(DSetB.ChrReads(chr).x, DSetA.ChrReads(chr).x);
    CommonReads(chr).MatchRef = (DSetB.ChrReads(chr).Alleles.Ref(CommonReads(chr).iB) == DSetA.ChrReads(chr).Alleles.Ref(CommonReads(chr).iA) );
    CommonReads(chr).MatchAlt = (DSetB.ChrReads(chr).Alleles.Alt(CommonReads(chr).iB) == DSetA.ChrReads(chr).Alleles.Alt(CommonReads(chr).iA) );
    CommonReads(chr).MatchBoth = CommonReads(chr).MatchAlt & CommonReads(chr).MatchRef;
    CommonReads(chr).MatchBorA = CommonReads(chr).MatchAlt | CommonReads(chr).MatchBoth;
end

[f, spl]  = plotAllChrNt(CommonReads, 'MatchBoth','yscale','lin','ylim',[-1 2], 'plotfun', @(x,y)plot(x,y,'rx') );


plotAllChrNt(CommonReads, 'MatchBorA', 'ylim',[-1 2],...
    'plotfun',@(x,y)scatter(x,y,3,'bo'), 'yscale', 'lin',...
    'OldSP', spl, 'OldFig', f);

CommonReads = rmfield(CommonReads, {'iA','iB'});
CommonReads = rmfield(CommonReads, {'MatchRef', 'MatchAlt'});
Description = 'A.thaliana, HL7 vs AB1';
save('datafiles/CommonReads.mat', 'CommonReads', 'Description')