function [ AR, cSlctChrLp, cStatChrLp, neutralEvidenceThrNorm, normFactor, totIntChrSum ] = ...
              runVarAlpha(AR,  Alpha, ChrMap, varargin )
%runVarAlpha -- runs the F-B algorithm on all chromosomes  with varied
% linkage relaxation factor Alpha

if nargin>3 && isscalar(varargin{1}) && (varargin{1}<=1)
    SUBSAMPLE = varargin{1};
else
    SUBSAMPLE = 1;
end
%% general experimental constants:
%= number of plants:
study.N = 50;
%= number of potentially positive plants by a SNP:
study.kvect = uint32(0: 1: study.N)';
%= number of chromosomes:
study.chrnum = length(ChrMap);

nX = numel(AR.x);

if SUBSAMPLE<1
    aInds = false(nX, 1);
    for chr = study.chrnum :-1:1
        nXc = sum(AR.chromosome == chr);
        cInds = logical(rand( nXc , 1) < max(SUBSAMPLE, 4/nXc) );
        aInds(AR.chromosome == chr) = cInds;
    end
        AR = selectFieldIndices(AR, aInds);    
end



%% initialization of the Calculation loop
nAlpha = numel(Alpha);
MT = numel(AR.x);
M = zeros(study.chrnum, 1);  % number of reads on the chromosome
%= log-likelihood of the chromosome to be stationary
cStatChrLp = zeros(study.chrnum, nAlpha);
%= log-likelihood of the chromosome to be under selection
cSlctChrLp = zeros(study.chrnum, nAlpha);
%= log-likelihood of the locus to be under selection (within chromosome)
AR.logPoSlct = zeros(MT , nAlpha);
AR.logPoint = zeros(MT, nAlpha);
%=

%%   Calculation cycle
for chr = 1: study.chrnum;
    ticInit = tic;
    
    [ inds, M(chr), x, q, r,  contrib ] = recastChromosomeReads( AR(1), chr );
    fprintf('\t log10 Alpha =')
    for aa = 1:numel(Alpha)
        fprintf('%3.2f', log10(Alpha(aa)) )
        [  AR.logPoSlct(inds, aa), cSlctChrLp(chr, aa), cStatChrLp(chr, aa),...
            ]  = ...
            estimateLikelihoodsOnChromosome( ChrMap(chr), [], [], study.N,...
            x, q, r, contrib, Alpha(aa));
         fprintf('\b\b\b\b')
    end
    %== check for NaNs
    fprintf('\n')
    fprintf('\t The iterations for the chr.#\t%u\t took \t%4.2f\t s \t SNPs:\t%u \n',...
        chr, toc(ticInit), sum(inds) )
    %== Ready!
end
neutralEvidenceThr =  -M*log10(study.N+1);
%
for aa = 1:numel(Alpha)
    %% Normalize internally
    [AR.xSlctLpoNC(:, aa), totIntChrSum(:, aa)] = normalizeChrInternally(AR.logPoSlct(:, aa), cSlctChrLp(:, aa), cStatChrLp(:, aa), AR.chromosome, study.chrnum);
    neutralEvidenceThrNC(:, aa) = neutralEvidenceThr - totIntChrSum(:, aa);
    
    %% Normalize externally
    normFactor(1, aa) = calcMarginal(AR.xSlctLpoNC(:, aa));
    AR.xSlctLpoNorm(:, aa)  = AR.xSlctLpoNC(:, aa) - normFactor(1, aa);
    
    neutralEvidenceThrNorm(:, aa) = neutralEvidenceThrNC(:, aa) - normFactor(1, aa);
end

cTotL = cSlctChrLp + cStatChrLp;

end