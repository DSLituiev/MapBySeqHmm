function [logPobsSel, logPobsStat, varargout] = ...
    propagateProbAlongChr(distanceM, N, E, varargin)
% propagates probability along a chromosome given experimental data and
% model (no selection / selection / selection type).
% Calculates transition(T), emission(E), and cumulative T-E matrices
% and wraps the 'calcLogPobs' function
%% process input
if  nargin>4 && isnumeric(varargin{1}) && numel(varargin{1}) == N+1
    pSelectionModel = varargin{1}(:);
else % selection probability not specified
    pSelectionModel = zeros(N+1, 1); pSelectionModel(N+1) = 1;
end

%% calculate Transition matrices
T = transition3D_expm( N, abs(diff(distanceM)) );

%% initialize constants and compute Emission matrix and vectors
M = size(distanceM, 1);

%% sanity check
if   any(T(:)<0)
    warning('propagateProbAlongChr:TNegInput', 'T matrix has negative values!')
end

%% calculate cumulative matrices
%= transpose the emission matrix (E)!
CM = calcCumMatrices(M,E',T); 

if any(isnan(CM.scaleA))
    warning('propagateProbAlongChr:CumMatr_NaNs', 'NaNs in cumulative matrices!')
end

%% calculate the log-likelihoods of observed data given models (m, pSelectionModel)
logPobsSel  = calcLogPobs(M, N, CM, T, false, pSelectionModel);
logPobsStat = calcLogPobs(M, N, CM, T, true, []);

if nargout>2
    varargout{1} = T;
end
% not normalized !
