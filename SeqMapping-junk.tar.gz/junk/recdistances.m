function Pos_M_x = recdistances(ChrMap, x)
% rec distances pairwise

Pos_M_x = (interp1(ChrMap.nt, ChrMap.cM, double(x),'pchip','extrap'));
