% Covariance matrix test
n = 100;

kk_ind = 3;
dvect = [.8, .83, .9, .97, 1, 1.05, 1.07, 1.1, 1.12, 1.15, 1.2, 1.24, 1.27];
N = length(dvect);

tic 
[Sigma3,Mu3]= assemble_covmatr_3D(dvect,n,N);
toc
SLR = splitcovmat(Sigma3);


kk_vect = false(1,N); kk_vect(kk_ind) = true;
[A, DD] = DistComplHaldane(dvect);
[Sigma,Mu, SigmaL, SigmaR]= asscovmatr2(DD,A,n,N,kk_ind);

[XX, YY] = meshgrid(dvect,dvect);

figure;surf(XX, YY, Sigma,'LineStyle', 'none')%,'FaceColor','interp','FaceLighting','phong');
view(0,90); axis square
% nexp = [100, 96, 100, 95, 93,];
% muSmu = nexp*pinv(Sigma)*nexp';
% prefact = 
% y = mvnpdf(nexp,A(kk_vect,:),Sigma1)

ddiff_dist = diff(dvect);
g = exp(-ddiff_dist).*cosh(ddiff_dist);
h = 1-g;

P_XY = g(2);
P_xY = h(2);
P_VX_givX = g(1);
P_Vx_givx = h(1);

d_VY = sum(ddiff_dist(1:2));

% P_VXY = prod(g(1:2))
P_VXY = P_VX_givX*P_XY;
P_VxY = prod(h(1:2));
% P_VY = exp(-d_VY)*cosh(d_VY);
P_VY = P_VXY + P_VxY

% sigma_VX = n*(P_VXY - P_XY * P_VY )
sigma_VX = n*P_XY *(P_VX_givX -  P_VY)
% n*P_VY*(P_VX_givX -  P_XY )
sigma2_X = n*P_XY*(1-P_XY);
sigma2_V = n*P_VY*(1-P_VY);

SigmaHandmade = [sigma2_V, sigma_VX;...
         sigma_VX,  sigma2_X]
     
[~,pos]= chol(SigmaHandmade)

