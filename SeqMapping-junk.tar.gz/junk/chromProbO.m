classdef chromProbO
    properties
        x;
        q;
        r;
        E;
        T;
        A;
        B;
        contrib;
        c;
        logAlpha;
        logBeta;
        M;
        Np; % N + 1 , where N is the number of individuals
        kvect;
        Pz;
        Pout;
        PoutFull;
        PoutFullFlat;
        Pstat;
        Pflat;
        Psel; % P under selection
    end
    
    methods

        
        function obj = getChromosome(bigObj, cc)
            obj = chromProb();
            propNames = properties(bigObj);
            inds = logical(cc == bigObj.chromosome);
            for ii = 1:numel(propNames)
                if any(strcmpi(propNames{ii}, properties(obj)))
                    s = size(bigObj.(propNames{ii}),1);
                    switch s
                        case bigObj.Mtot
                            obj.(propNames{ii}) = bigObj.(propNames{ii})(inds, :);
                        case bigObj.chromosomeNumber
                            obj.(propNames{ii}) = bigObj.(propNames{ii})(cc);
                        otherwise
                            obj.(propNames{ii}) = bigObj.(propNames{ii});
                    end
                end
            end
            obj.M = sum(inds);
            obj.Np = size(obj.E, 2);
        end
        
        function [obj, varargout] = run(obj, varargin)
            obj = obj.crossMatr;
            if nargin>1 && any(strcmpi('safe', varargin))
                obj = obj.cumMatrSafe;
            else
                obj = obj.cumMatr;
            end
            obj = obj.runFBflat;
            obj = obj.runFBstat;            
            obj = obj.runFBselection;
            if nargin>1 && any(strcmpi('plot', varargin))
                varargout{1} = figure;
                plot(obj.x, obj.Pstat)
                hold all
                plot(obj.x, obj.Pflat)
                plot(obj.x, obj.Pout)
            elseif nargout>1
                varargout{1} = [];
            end
        end

       function obj = calcEmissionBBUmix(obj, theta, lambda1,  varargin)
           if nargin<3 || (~ isobject(varargin{1}))
               study = population(obj.Np-1);               
           else
               study = varargin{1};
           end
           emissionHandle = @(q, r, study)emissionMixBetaBinomial(q, r, study, theta, lambda1);
%             emissionHandle = @(q, r, study)emissionBetaBinomial(q, r, study, theta);
%             emissionHandle = @(qq, rr, ff)emissionk0(qq, rr, study);
            
            obj.contrib = ones(obj.M, 1);
            [obj.E, obj.c] = wrapEmissionMatrix(obj.q, obj.r, study, emissionHandle, obj.contrib);
       end
        
        function obj = chromProb(Ein, Tin, varargin)
            if nargin>0
                obj.E = Ein;
                obj.T = Tin;
                obj.Np = size(Ein, 2);
                obj.M = size(Ein, 1);
                obj.kvect = 0:1:(obj.Np-1);
                if nargin>2
                    obj.x = varargin{1};
                else
                    obj.x = 1:obj.M;
                end
            end
        end
        % add emission
        function obj = set.E(obj, Ein)
            if nargin>0
                obj.E = Ein;                
                obj.Np = size(Ein, 2);
            end
        end
        function obj = set.T(obj, Tin)
            if nargin>0
                obj.T = Tin;
            end
        end
        %% calculate A-matrix
        function obj = crossMatr(obj)
            if ~isempty(obj.T)
                obj.A =  bsxfun(@times, ...
                    permute( obj.E(1:end-1, :), [2, 3, 1] ), obj.T ) ;
                %% backward matrix (B)
                 obj.B =  permute( bsxfun(@times, ...
                    permute( obj.E(2:end, :), [2, 3, 1] ), obj.T ) ,...
                    [2, 1, 3] );
                
% B = permute( bsxfun(@times, ...
%     permute( E(:, 2:end), [1, 3, 2] ), T ),...
%     [2, 1, 3] );
            else
                warning('crossMatr:emptyT', 'define transition matrix T first!');
            end
        end
        %% calculate the cumulative matrices
        function obj = cumMatr(obj)
            %% forward
            Ac = obj.E( end, :)';            
            logAlpha0 = -inf(obj.Np, obj.M);
            logAlpha0((1:obj.Np)', obj.M) = log10(Ac);
        
            for m = obj.M-1:-1:1
                Ac = obj.A(:,:, m) * Ac * obj.Np ;
                logAlpha0(:, m)= log10(Ac);
            end
            obj.logAlpha = bsxfun(@minus, logAlpha0,...
                ((obj.M-1):-1:0) * log10(obj.Np) )';
            %% backward
            Bc = obj.E( 1, :);
            logBeta0 = -inf(obj.Np, obj.M);
            logBeta0(:,1) = log10(Bc);            
            for m = 2:1:obj.M
                Bc = Bc * obj.B(:,:, m-1) * obj.Np ;
                logBeta0(:, m) = log10(Bc);
            end
            obj.logBeta = bsxfun(@minus, logBeta0,...
                (0:(obj.M-1) )* log10(obj.Np) )';
        end
        %% calculate the cumulative matrices in a safe way
        function obj = cumMatrSafe(obj)
            if ~isempty(obj.Np)
                %% forward
                Ac = obj.E( end, :)';
                logAlpha0 = -inf(obj.Np, obj.M);
                logAlpha0(1: obj.Np, obj.M) = log10(Ac);
                
                scalePrev = 0;
                scaleA = zeros(obj.M, 1);
                
                for m = (obj.M-1):-1:1
                    Ac = obj.A(:,:, m) * (Ac * 10.^(scaleA(m+1) - scalePrev) );
                    logAlpha0(:, m)= log10(Ac) - scaleA(m+1);
                    scalePrev = scaleA(m+1);
                    scaleA(m) = - max( logAlpha0(:, m) );
                end
                obj.logAlpha = logAlpha0';% bsxfun(@minus, logAlpha0', scaleA );
                %% backward
                Bc = obj.E( 1, :);
                logBeta0 = -inf(obj.Np, obj.M);
                logBeta0(1: obj.Np, 1) = log10(Bc);
                scalePrev = 0;
                scaleB = zeros(obj.M-1, 1);
                
                for m = 2:1:obj.M
                    Bc = Bc * obj.B(:,:, m-1) * (10.^(scaleB(m-1) - scalePrev));
                    logBeta0(:, m) = log10(Bc) - scaleB(m-1);
                    scalePrev = scaleB(m-1);
                    scaleB(m) = - max(logBeta0(:, m));
                end
                obj.logBeta = logBeta0'; % bsxfun(@minus, logBeta0', scaleB );
            else
                warning('cumMatrSafe:emptyNp', 'define T first!')
            end
        end
        %% forward-backward
        function obj = runFB(obj, Pin)
            if nargin<2
                obj.Pz = ones(obj.Np,1);
            else
                obj.Pz = Pin;
            end
            obj = runFBinternal(obj);
        end
        
        function obj = runFBselection(obj)
            obj.Pz = zeros(obj.Np, 1); obj.Pz(obj.Np) = 1;
            obj = runFBinternal(obj);
            obj.Psel = obj.Pout;% median(obj.Pout);
        end
            
       
        function obj = runFBstat(obj)
            obj.Pz = StationaryDistr(obj.Np-1);
            obj = runFBinternal(obj);
            obj.Pstat = obj.Pout;% median(obj.Pout);
        end
        
        function obj = runFBflat(obj)
            obj.Pz = ones(obj.Np,1);
            obj = runFBinternal(obj);
            obj.Pflat = obj.Pout;
            obj.PoutFullFlat = obj.PoutFull;
        end
        
        function PFF = get.PoutFullFlat(obj)
         if isempty(obj.PoutFullFlat)
             obj = runFBflat(obj);
         end
         PFF = obj.PoutFullFlat;
        end
        
        %% FB - final step
        function obj = runFBinternal(obj)
            J = squeeze(sum(bsxfun(@times, obj.Pz, obj.T), 2))'; % [1 x Np] x [Np x Np]
            
            obj.PoutFull = obj.logBeta(1:end-1,:) + log10(J) + obj.logAlpha(2:end,:);
            
            J(obj.M, :)= (obj.T(:,:,end)'*obj.Pz)';
            
            obj.PoutFull(obj.M, :) = obj.logBeta(1:end-1,:) + log10(J) + obj.logAlpha(2:end,:);
            
            
            obj.Pout = calcMarginal(obj.PoutFull, 2);
        end
        %% psedu FB for totally flat emission
        
%         function obj = runFBFlat(obj)
%             obj.logBeta(2:end)'.*obj.T
%             obj.PoutFull = bsxfun(@plus, (obj.logAlpha + obj.logBeta), log10(obj.Pz)');
%             obj.Pout = calcMarginal(obj.PoutFull, 2);
%         end
        
        function fh = plotPkx(obj)
            fh = figure();
            surf(obj.kvect, z.x, z.PoutFull, 'linestyle', 'none');
            view(90, 90)
        end
    end
end