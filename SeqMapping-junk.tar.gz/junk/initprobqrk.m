function Pqrk = initprobqrk(min_r,max_r,min_q,max_q,n)
% P[q|r,k]
% input
% n -- number of plants:
% min_r -- minimum number of reads:
% max_r -- maximum number of reads:
% min_q -- min number of positive reads:
% max_q -- max number of positive reads:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% call as:
% Pfrq(q0-min_q+1,r0-min_r+1,k0+1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% number of potentially positive plants by a SNP:
k = (0:1:n)';
% number of reads
r = min_r:1:max_r;
% number of positive reads:
q = min_q:1:max_q;

[rr,qq,ff] = ndgrid(r,q,k./n);

Pqrk = binopdf(qq,rr,ff);
