function varargout = plotemission(E, kvect, chr, varargin)
% plots the emission matrix
% 
% ====== Input  ====== 
%
% - E                -- emission matrix
% - kvect            -- vector 1:1:(number of plants)
% - chr              -- chromosome #
% - xMbp (optional)  -- positions of loci ( integer )
%
% ====== Output ======
% - varargout:
%    - ff -- figure handle
%    - ss -- surface plot handle 

%% check the input parameters
p = inputParser;
addRequired(p,     'E',    @isnumeric);
addRequired(p, 'kvect',    @isnumeric);
addOptional(p,  'x', 0, @isnumeric);

parse(p, E, kvect, varargin{:});

ff = figure('name',sprintf('Emission Matrix for the Chromosome #%u',chr));
if ~isscalar(p.Results.x)
ss = surf(single(p.Results.x)*1e-6, kvect , E);
    xlabel('x, Mbp'); 
    xlim([0,1]*single(max(p.Results.x)*1e-6))
else
ss = surf(1:size(E,2) , kvect, E);
    xlabel('locus #'); 
    xlim([0,1]*size(E,2));
end
ylabel('k');
set(ss, 'linestyle', 'none');
view(0,90)

varargout = {ff, ss};