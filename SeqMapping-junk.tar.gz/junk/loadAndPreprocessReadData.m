function AR = loadAndPreprocessReadData(dataPath)

%% load data per se
AR = subtractBackGroundGenotype(dataPath);

AR = calcDx(AR,  @(x)nanmin(x, [], 2));
%=     find characteristic length scale for the 'correct' SNPs
%= as the mode for 'correct' SNP fraction (uses log-Gaussian mixture model)
[AR, mu ] = unmixRepeatsOne( AR, 'dx', '', 'modeNum', 2);
% [AR, mu, ~] = unmixRepeats( AR, 'dx');
%= the characteristic length scale
sigmaDx = 1*10^( max(mu.dx) );
%= calculate the smoothed SNP density (SNP sites / bp)
AR.W = calcReadDensity( AR, sigmaDx );

[AR] = unmixRepeatsTwo( AR, 'W', 'dx', '', 'modeNum', 3,...
    'peakVar1', 'max', 'peakVar2', 'max' );
