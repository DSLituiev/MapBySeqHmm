function [logPobs, M] = likelihoodNonUniformEmission(E, N, chromsome)


for chr = max(chromsome):-1:1
    inds = logical(chromsome ~= chr);
    M(chr,1) = sum(inds);
    logPst= log10(StationaryDistr(N)');
    pE = (sum(log10(E(inds,:)),1) );
    logPobs(chr,1) = calcMarginalDim(bsxfun(@plus, pE , logPst) , 2);
end