classdef figHistory
    properties        
        figs;
        axes;
        lines;
        yLims;
        varNames;
    end
    
    
end
    