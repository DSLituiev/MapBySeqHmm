classdef chromProb < handle
    %  %#codegen
    properties
        parent;
        chromosome = 0;
        x;
        q;
        r;
        quality;
        E;
        Especial;
        T;
        A;
        contrib;
        c;
        logAlpha;
        logBeta;
        kvect;
        Pz;
        Pout;
        PoutFull;
        PoutFullFlat;
        Pstat;
        Pflat;
        Psel; % P under selection
    end
    properties (Dependent = true)
        flagRaw = true;
        M;
        Np; % N + 1 , where N is the number of individuals
        dx;
    end
    
    methods
        
        
        function obj = getChromosome(bigObj, cc)plot(obj.x(obj.ci{chr}), obj.xPstat(obj.ci{chr}))
                hold all
                plot(obj.x(obj.ci{chr}), obj.xPflat(obj.ci{chr}))
                plot(obj.x(obj.ci{chr}), obj.xPout(obj.ci{chr}))
                
            obj = chromProb();
            propNames = properties(bigObj);
            inds = logical(cc == bigObj.chromosome);
            for ii = 1:numel(propNames)
                if any(strcmpi(propNames{ii}, properties(obj)))
                    s = size(bigObj.(propNames{ii}),1);
                    switch s
                        case bigObj.Mtot
                            obj.(propNames{ii}) = bigObj.(propNames{ii})(inds, :);
                        case bigObj.chromosomeNumber
                            obj.(propNames{ii}) = bigObj.(propNames{ii})(cc);
                        otherwise
                            obj.(propNames{ii}) = bigObj.(propNames{ii});
                    end
                end
            end
            obj.Np = size(obj.E, 2);
        end
        %%
        function [obj, varargout] = run(obj, varargin)
            obj = obj.crossMatr;
            if nargin>1 && any(strcmpi('safe', varargin))
                obj = obj.cumMatrSafe;
            else
                obj = obj.cumMatr;
            end
            obj = obj.runFBflat;
            obj = obj.runFBstat;
            obj = obj.runFBselection;
            if nargin>1 && any(strcmpi('plot', varargin))
                varargout{1} = figure;
                plot(obj.x, obj.Pstat)
                hold all
                plot(obj.x, obj.Pflat)
                plot(obj.x, obj.Pout)
                legend({'stationary', 'flat', 'selection'})
            elseif nargout>1
                varargout{1} = [];
            end
        end
        
        function varargout = plot(obj, varargin)
            if nargin>1 && ishandle(varargin{1})
                varargout{1} = figure(varargin{1});
            else
                varargout{1} = figure;
            end
            if size(obj.x,1) == size(obj.Pout,1)
                
                plot(obj.x, obj.Pout)
                hold all
            else
                warning('plot:DimMismatch', 'dimension mismatch!')
            end
        end
        
        function obj = calcEmissionBBUmix(obj, theta, lambda1,  varargin)
            if nargin<3 || (~ isobject(varargin{1}))
                study = population(obj.Np-1);
            else
                study = varargin{1};
            end
            emissionHandle = @(q, r, study)emissionMixBetaBinomial(q, r, study, theta, lambda1);
            %             emissionHandle = @(q, r, study)emissionBetaBinomial(q, r, study, theta);
            %             emissionHandle = @(qq, rr, ff)emissionk0(qq, rr, study);
            
            obj.contrib = ones(obj.M, 1);
            [obj.E, obj.c] = wrapEmissionMatrix(obj.q, obj.r, study, emissionHandle, obj.contrib);
        end
        
        function obj = chromProb(Ein, Tin, varargin)
            if nargin>0
                obj.E = Ein;
                obj.T = Tin;
                obj.flagRaw = false;
                obj.Np = size(Ein, 2);
                obj.M = size(Ein, 1);
                obj.kvect = 0:1:(obj.Np-1);
                if nargin>2
                    obj.x = varargin{1};
                else
                    obj.x = 1:obj.M;
                end
            end
        end
        % add emission
        function obj = set.E(obj, Ein)
            if nargin>0
                obj.E = Ein;
            end
        end
        
        function Np = get.Np(obj)
            Np = size(obj.E, 2);
        end
        
        function M = get.M(obj)
            M = numel(obj.x);
        end
        
        function obj = set.M(obj, M)
            if ~(M == numel(obj.x, 1))
                warning('wrong value of M!')
            end
        end
        
        function dx = get.dx( obj )
                dxRaw = [NaN; diff(double(obj.x))];
                dxRaw(dxRaw < 0) = NaN;
                dxPair = [dxRaw, circshift(dxRaw,-1)];
                dx(inds,1) = nanmin(dxPair, 2);
        end
        
        function obj = set.T(obj, Tin)
            if nargin>0
                obj.T = Tin;
            end
        end
        function flRaw = get.flagRaw(obj)
            flRaw = isempty(obj.T);
        end % flRaw get method
        
        function obj = set.flagRaw(obj, flValue)
            if ~flValue
                obj.T = [];
                obj.A = [];
                obj.logAlpha = [];
                obj.logBeta = [];
                obj.Pout = [];
                obj.PoutFull = [];
                obj.PoutFullFlat = [];
                obj.Pstat = [];
                obj.Pflat = [];
                obj.Psel = []; % P under selection
                fprintf('transition matrix and related information has been cleared for the chromosome %u', obj.chromosome)
            end
            
        end % flRaw set method
        
        function obj = filterBy(obj, field, fhandle)
            % filter raw data by indices
            inds = fhandle(obj.(field));
            obj.x = obj.x(inds);
            obj.r = obj.r(inds);
            obj.q = obj.q(inds);
            if ~isempty(obj.quality)
                obj.quality = obj.quality(inds);
            end
            if ~isempty(obj.E)
                obj.E = obj.E(inds, :);
            end
            obj.flagRaw = true;
        end
        %%
        function obj = calcT(obj, pop, ChrMapChr, Alpha)
            %= calculate Transition matrices
            tvect = abs(diff(Alpha * 0.01* recdistances(ChrMapChr, obj.x))) ;
            obj.T = zeros(obj.Np,obj.Np, obj.M-1);
            %= calculate
            for ii = 1:(obj.M-1)
                if tvect(ii)~=0 && ~isinf(tvect(ii))
                    obj.T(:,:,ii) = expm(pop.Q*tvect(ii));
                elseif  tvect(ii)==0
                    obj.T(:,:,ii) = eye(pop.Np);
                elseif tvect(ii)== Inf
                    obj.T(:,:,ii) = repmat(pop.Pstat, [1, pop.Np]);
                end
            end
            %= sanity check
            if   any(obj.T(:)<0)
                warning('transition3D_expm:TNegInput', 'T matrix has negative values!')
            end
            
        end
        
        %% calculate A-matrix
        function obj = crossMatr(obj)
            if ~isempty(obj.T)
                obj.A =  bsxfun(@times, ...
                    permute( obj.E(1:end-1, :), [2, 3, 1] ), obj.T ) ;
            else
                warning('crossMatr:emptyT', 'define transition matrix T first!');
            end
        end
        %% calculate the cumulative matrices
        function obj = cumMatr(obj)
            %% forward
            Ac = obj.E( end, :)';
            logAlpha0((1:obj.Np)', obj.M) = log10(Ac);
            
            for m = obj.M-1:-1:1
                Ac = obj.A(:,:, m) * Ac * obj.Np ;
                logAlpha0(:, m)= log10(Ac);
            end
            obj.logAlpha = bsxfun(@minus, logAlpha0,...
                ((obj.M-1):-1:0) * log10(obj.Np) )';
            %% backward
            Bc = ones(1,obj.Np);
            %             obj.logBeta(:,1) = log10(Bc);
            logBeta0(1: obj.Np, 1) = 0;
            logBeta0(1:obj.Np, obj.M-1) = -inf( obj.Np,1);
            
            for m = 2:1:obj.M
                Bc = Bc * obj.A(:,:, m-1)' * obj.Np ;
                logBeta0(:, m) = log10(Bc);
            end
            obj.logBeta = bsxfun(@minus, logBeta0,...
                (0:(obj.M-1) )* log10(obj.Np) )';
        end
        %% calculate the cumulative matrices in a safe way
        function obj = cumMatrSafe(obj)
            if ~isempty(obj.Np)
                
                obj.logAlpha = -inf(obj.M, obj.Np);
                obj.logBeta  = -inf(obj.M, obj.Np);
                
                %% forward
                Ac = obj.E( end, :)';
                obj.logAlpha(obj.M, 1: obj.Np) = log10(Ac');
                
                scalePrev = 0;
                scaleA = zeros(obj.M, 1);
                
                for m = (obj.M-1):-1:1
                    Ac = obj.A(:,:, m) * (Ac * 10.^(scaleA(m+1) - scalePrev) );
                    obj.logAlpha(m, :)= log10(Ac) - scaleA(m+1);
                    scalePrev = scaleA(m+1);
                    scaleA(m) = - max( obj.logAlpha( m, :) );
                end
                
                %% backward
                Bc = ones(1, obj.Np);
                obj.logBeta(1, 1: obj.Np) = 0;
                
                scalePrev = 0;
                scaleB = zeros(obj.M-1, 1);
                
                for m = 2:1:obj.M
                    Bc = Bc * obj.A(:,:, m-1)' * (10.^(scaleB(m-1) - scalePrev));
                    obj.logBeta(m, :) = log10(Bc) - scaleB(m-1);
                    scalePrev = scaleB(m-1);
                    scaleB(m) = - max(obj.logBeta(m, :));
                end
               %  obj.logBeta = logBeta0'; % bsxfun(@minus, logBeta0', scaleB );
            else
                warning('cumMatrSafe:emptyNp', 'define T first!')
            end
        end
        %% forward-backward
        function obj = runFB(obj, Pin)
            if nargin<2
                obj.Pz = ones(obj.Np,1);
            else
                obj.Pz = Pin;
            end
            obj = runFBinternal(obj);
        end
        
        function obj = runFBstat(obj)
            obj.Pz = StationaryDistr(obj.Np-1);
            obj = runFBinternal(obj);
            obj.Pstat = obj.Pout;% median(obj.Pout);
        end
        
        function obj = runFBflat(obj)
            obj.Pz = ones(obj.Np,1)./obj.Np;
            obj = runFBinternal(obj);
            obj.Pflat = obj.Pout;
            obj.PoutFullFlat = obj.PoutFull;
        end
        
        function PFF = get.PoutFullFlat(obj)
            if isempty(obj.PoutFullFlat)
                obj = runFBflat(obj);
            end
            PFF = obj.PoutFullFlat;
        end
        
        function obj = runFBselection(obj)
            obj.Pz = zeros(obj.Np, 1); obj.Pz(obj.Np) = 1;
            obj = runFBinternal(obj);
            obj.Psel = obj.Pout;% median(obj.Pout);
        end
        
        %% FB - final step
        function obj = runFBinternal(obj)
            if isempty(obj.A)|| isempty(obj.logAlpha ) || isempty(obj.logAlpha )
                obj = obj.crossMatr;
                obj = obj.cumMatr;
            end
            obj.PoutFull = bsxfun(@plus, (obj.logAlpha + obj.logBeta), log10(obj.Pz)');
            obj.Pout = calcMarginal(obj.PoutFull, 2);
        end
        %% psedo FB for totally flat emission
        
        function obj = runFBsubstituteE(obj)
            if isempty(obj.Especial)
                error('runFBThisFlat:noSpecialEmission', 'specify the special emission (obj.Especial) first')
            end
            obj.Pz = StationaryDistr(obj.Np-1);
            
            %  scaleAlpha = log10(obj.Np-1)*(obj.M:-1:1)';
            scaleAlpha = - median(obj.logAlpha, 2);
            logAlphaScaled = bsxfun(@plus, obj.logAlpha, scaleAlpha);
            
            logAs =  bsxfun(@plus,...
                permute(...
                log10(sum(bsxfun(@times , permute(10.^logAlphaScaled(2:end,:), [3,2,1]), obj.T), 2)),...
                [3,1,2]), -scaleAlpha(2:end)) ;
            logAs(obj.M,:) = zeros(1, obj.Np);
            
            obj.PoutFull = bsxfun(@plus, (obj.logBeta + logAs + log10(obj.Especial) ), log10(obj.Pz)');
            
            obj.Pout = calcMarginal(obj.PoutFull, 2);
        end
        %% emission
        function [obj, varargout] = calcEmission(obj, study, theta, lambda1, varargin)
            emissionHandle = @(q, r, study)emissionMixBetaBinomial(q, r, study, theta, lambda1);
            if nargin>4 && any(strcmpi({'special','s'}, varargin))
                [obj.Especial, obj.c] = wrapEmissionMatrix(obj.q, obj.r, study, emissionHandle, obj.contrib);
                if nargout>1
                    varargout{1} = obj.Especial;
                end
            else
                [obj.E, obj.c] = wrapEmissionMatrix(obj.q, obj.r, study, emissionHandle, obj.contrib);
            end            
        end
        
        %% plot
        function fh = plotPkx(obj)
            fh = figure();
            surf(obj.kvect, z.x, z.PoutFull, 'linestyle', 'none');
            view(90, 90)
        end
    end
end