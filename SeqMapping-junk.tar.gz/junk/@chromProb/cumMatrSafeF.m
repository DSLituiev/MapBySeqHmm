function [logAlpha, logBeta] = cumMatrSafeF(Np, M, E, A)
%#codegen
% calculate the cumulative matrices in a safe way

% assert(isa(Np,'double'));
assert(isscalar(Np));
% assert(isa(M,'double'));
assert(isscalar(M));
assert(isa(E,'double'));
assert(isa(A,'double'));

if ~isempty(Np)
%     if ~isempty(T)
%         A =  bsxfun(@times, ...
%             permute( E(1:end-1, :), [2, 3, 1] ), T ) ;
%         clear T
%     else
%         warning('crossMatr:emptyT', 'define transition matrix T first!');
%     end
    
    logAlpha = -inf(M, Np);
    logBeta  = -inf(M, Np);
    
    %% forward
    Ac = E( end, :)';
    logAlpha(M, :) = log10(Ac');
    
    scalePrev = 0;
    scaleA = zeros(M, 1);
    % for-loop frwd
    for m = (M-1):-1: 1
        Ac = A(:,:, m) * (Ac * 10.^(scaleA(m+1) - scalePrev) );
        logAlpha(m, :)= log10(Ac) - scaleA(m+1);
        scalePrev = scaleA(m+1);
        scaleA(m) = - max( logAlpha( m, :) );
    end
    
    %% backward
    Bc = ones(1, Np);
    logBeta(1, 1: Np) = 0;
    
    scalePrev = 0;
    scaleB = zeros(M-1, 1);
    
    for m = 2:1:M
        Bc = Bc * A(:,:, m-1)' * (10.^(scaleB(m-1) - scalePrev));
        logBeta(m, :) = log10(Bc) - scaleB(m-1);
        scalePrev = scaleB(m-1);
        scaleB(m) = - max(logBeta(m, :));
    end
else
    warning('cumMatrSafe:emptyNp', 'define T first!')
end
end