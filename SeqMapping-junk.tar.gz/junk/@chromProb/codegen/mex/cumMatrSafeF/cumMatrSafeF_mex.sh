MATLAB="/usr/local/MATLAB/R2013b"
Arch=glnxa64
ENTRYPOINT=mexFunction
MAPFILE=$ENTRYPOINT'.map'
PREFDIR="/home/dima/.matlab/R2013b"
OPTSFILE_NAME="./mexopts.sh"
. $OPTSFILE_NAME
COMPILER=$CC
. $OPTSFILE_NAME
echo "# Make settings for cumMatrSafeF" > cumMatrSafeF_mex.mki
echo "CC=$CC" >> cumMatrSafeF_mex.mki
echo "CFLAGS=$CFLAGS" >> cumMatrSafeF_mex.mki
echo "CLIBS=$CLIBS" >> cumMatrSafeF_mex.mki
echo "COPTIMFLAGS=$COPTIMFLAGS" >> cumMatrSafeF_mex.mki
echo "CDEBUGFLAGS=$CDEBUGFLAGS" >> cumMatrSafeF_mex.mki
echo "CXX=$CXX" >> cumMatrSafeF_mex.mki
echo "CXXFLAGS=$CXXFLAGS" >> cumMatrSafeF_mex.mki
echo "CXXLIBS=$CXXLIBS" >> cumMatrSafeF_mex.mki
echo "CXXOPTIMFLAGS=$CXXOPTIMFLAGS" >> cumMatrSafeF_mex.mki
echo "CXXDEBUGFLAGS=$CXXDEBUGFLAGS" >> cumMatrSafeF_mex.mki
echo "LD=$LD" >> cumMatrSafeF_mex.mki
echo "LDFLAGS=$LDFLAGS" >> cumMatrSafeF_mex.mki
echo "LDOPTIMFLAGS=$LDOPTIMFLAGS" >> cumMatrSafeF_mex.mki
echo "LDDEBUGFLAGS=$LDDEBUGFLAGS" >> cumMatrSafeF_mex.mki
echo "Arch=$Arch" >> cumMatrSafeF_mex.mki
echo OMPFLAGS= >> cumMatrSafeF_mex.mki
echo OMPLINKFLAGS= >> cumMatrSafeF_mex.mki
echo "EMC_COMPILER=" >> cumMatrSafeF_mex.mki
echo "EMC_CONFIG=optim" >> cumMatrSafeF_mex.mki
"/usr/local/MATLAB/R2013b/bin/glnxa64/gmake" -B -f cumMatrSafeF_mex.mk
