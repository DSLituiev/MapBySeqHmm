/*
 * mtimes.h
 *
 * Code generation for function 'mtimes'
 *
 * C source code generated on: Wed Jun 11 19:52:42 2014
 *
 */

#ifndef __MTIMES_H__
#define __MTIMES_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "mwmathutil.h"

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "cumMatrSafeF_types.h"

/* Function Declarations */
extern void b_dynamic_size_checks(const emxArray_real_T *a, const emxArray_real_T *b);
extern void dynamic_size_checks(const emxArray_real_T *a, const emxArray_real_T *b);
#endif
/* End of code generation (mtimes.h) */
