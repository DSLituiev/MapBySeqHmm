/*
 * _coder_cumMatrSafeF_info.h
 *
 * Code generation for function 'cumMatrSafeF'
 *
 * C source code generated on: Wed Jun 11 19:52:42 2014
 *
 */

#ifndef ___CODER_CUMMATRSAFEF_INFO_H__
#define ___CODER_CUMMATRSAFEF_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* End of code generation (_coder_cumMatrSafeF_info.h) */
