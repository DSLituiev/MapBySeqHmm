classdef chromProb
    %#codegen
    properties
        x;
        q;
        r;
        E;
        Especial;
        T;
        A;
        contrib;
        c;
        logAlpha;
        logBeta;
        M;
        Np; % N + 1 , where N is the number of individuals
        kvect;
        Pz;set
        Pout;
        PoutFull;
        PoutFullFlat;
        Pstat;
        Pflat;
        Psel; % P under selection
    end
    
    methods
        
        %%
        function [obj, varargout] = run(obj, varargin)
            obj = obj.crossMatr;
            if nargin>1 && any(strcmpi('safe', varargin))
                obj = obj.cumMatrSafe;
            else
                obj = obj.cumMatr;
            end
            obj = obj.runFBflat;
            obj = obj.runFBstat;
            obj = obj.runFBselection;
            if nargin>1 && any(strcmpi('plot', varargin))
                varargout{1} = figure;
                plot(obj.x, obj.Pstat)
                hold all
                plot(obj.x, obj.Pflat)
                plot(obj.x, obj.Pout)
            elseif nargout>1
                varargout{1} = [];
            end
        end
        
        function varargout = plot(obj, varargin)
            if nargin>1 && ishandle(varargin{1})
                varargout{1} = figure(varargin{1});
            else
                varargout{1} = figure;
            end
            if size(obj.x,1) == size(obj.Pout,1)
                
                plot(obj.x, obj.Pout)
                hold all
            else
                warning('plot:DimMismatch', 'dimension mismatch!')
            end
        end
        
        function obj = calcEmissionBBUmix(obj, theta, lambda1,  varargin)
            if nargin<3 || (~ isobject(varargin{1}))
                study = population(obj.Np-1);
            else
                study = varargin{1};
            end
            emissionHandle = @(q, r, study)emissionMixBetaBinomial(q, r, study, theta, lambda1);
            %             emissionHandle = @(q, r, study)emissionBetaBinomial(q, r, study, theta);
            %             emissionHandle = @(qq, rr, ff)emissionk0(qq, rr, study);
            
            obj.contrib = ones(obj.M, 1);
            [obj.E, obj.c] = wrapEmissionMatrix(obj.q, obj.r, study, emissionHandle, obj.contrib);
        end
        
        function obj = chromProb(Ein, Tin, varargin)
            if nargin>0
                obj.E = Ein;
                obj.T = Tin;
                obj.Np = size(Ein, 2);
                obj.M = size(Ein, 1);
                obj.kvect = 0:1:(obj.Np-1);
                if nargin>2
                    obj.x = varargin{1};
                else
                    obj.x = 1:obj.M;
                end
            end
        end
        % add emission
        function obj = set.E(obj, Ein)
            if nargin>0
                obj.E = Ein;
                obj.Np = size(Ein, 2);
            end
        end
        function obj = set.T(obj, Tin)
            if nargin>0
                obj.T = Tin;
            end
        end
        %% calculate A-matrix
        function obj = crossMatr(obj)
            if ~isempty(obj.T)
                obj.A =  bsxfun(@times, ...
                    permute( obj.E(1:end-1, :), [2, 3, 1] ), obj.T ) ;
            else
                warning('crossMatr:emptyT', 'define transition matrix T first!');
            end
        end
        
        %% calculate the cumulative matrices in a safe way
        function obj = cumMatr(obj)
            if ~isempty(obj.Np)
                
                obj.logAlpha = -inf(obj.M, obj.Np);
                obj.logBeta  = -inf(obj.M, obj.Np);
                
                %% forward
                Ac = obj.E( end, :)';
                obj.logAlpha(obj.M, 1: obj.Np) = log10(Ac');
                
                scalePrev = 0;
                scaleA = zeros(obj.M, 1);
                
                for m = (obj.M-1):-1:1
                    Ac = obj.A(:,:, m) * (Ac * 10.^(scaleA(m+1) - scalePrev) );
                    obj.logAlpha(m, :)= log10(Ac) - scaleA(m+1);
                    scalePrev = scaleA(m+1);
                    scaleA(m) = - max( obj.logAlpha( m, :) );
                end
                
                %% backward
                Bc = ones(1, obj.Np);
                obj.logBeta(1, 1: obj.Np) = 0;
                
                scalePrev = 0;
                scaleB = zeros(obj.M-1, 1);
                
                for m = 2:1:obj.M
                    Bc = Bc * obj.A(:,:, m-1)' * (10.^(scaleB(m-1) - scalePrev));
                    obj.logBeta(m, :) = log10(Bc) - scaleB(m-1);
                    scalePrev = scaleB(m-1);
                    scaleB(m) = - max(obj.logBeta(m, :));
                end
                obj.logBeta = logBeta0'; % bsxfun(@minus, logBeta0', scaleB );
            else
                warning('cumMatrSafe:emptyNp', 'define T first!')
            end
        end
        %% forward-backward
        function obj = runFB(obj, Pin)
            if nargin<2
                obj.Pz = ones(obj.Np,1);
            else
                obj.Pz = Pin;
            end
            obj = runFBinternal(obj);
        end
        
        function obj = runFBstat(obj)
            obj.Pz = StationaryDistr(obj.Np-1);
            obj = runFBinternal(obj);
            obj.Pstat = obj.Pout;% median(obj.Pout);
        end
        
        function obj = runFBflat(obj)
            obj.Pz = ones(obj.Np,1)./obj.Np;
            obj = runFBinternal(obj);
            obj.Pflat = obj.Pout;
            obj.PoutFullFlat = obj.PoutFull;
        end
        
        function PFF = get.PoutFullFlat(obj)
            if isempty(obj.PoutFullFlat)
                obj = runFBflat(obj);
            end
            PFF = obj.PoutFullFlat;
        end
        
        function obj = runFBselection(obj)
            obj.Pz = zeros(obj.Np, 1); obj.Pz(obj.Np) = 1;
            obj = runFBinternal(obj);
            obj.Psel = obj.Pout;% median(obj.Pout);
        end
        
        %% FB - final step
        function obj = runFBinternal(obj)
            if isempty(obj.A)|| isempty(obj.logAlpha ) || isempty(obj.logAlpha )
                obj = obj.crossMatr;
                obj = obj.cumMatr;
            end
            obj.PoutFull = bsxfun(@plus, (obj.logAlpha + obj.logBeta), log10(obj.Pz)');
            obj.Pout = calcMarginal(obj.PoutFull, 2);
        end
        %% psedu FB for totally flat emission
        
        function obj = runFBsubstituteE(obj)
            if isempty(obj.Especial)
                error('runFBThisFlat:noSpecialEmission', 'specify the special emission (obj.Especial) first')
            end
            obj.Pz = StationaryDistr(obj.Np-1);
            
            %  scaleAlpha = log10(obj.Np-1)*(obj.M:-1:1)';
            scaleAlpha = - median(obj.logAlpha, 2);
            logAlphaScaled = bsxfun(@plus, obj.logAlpha, scaleAlpha);
            
            logAs =  bsxfun(@plus,...
                permute(...
                log10(sum(bsxfun(@times , permute(10.^logAlphaScaled(2:end,:), [3,2,1]), obj.T), 2)),...
                [3,1,2]), -scaleAlpha(2:end)) ;
            logAs(obj.M,:) = zeros(1, obj.Np);
            
            obj.PoutFull = bsxfun(@plus, (obj.logBeta + logAs + log10(obj.Especial) ), log10(obj.Pz)');
            
            obj.Pout = calcMarginal(obj.PoutFull, 2);
        end
        %% emission
        function [obj, varargout] = calcEmission(obj, study, theta, lambda1, varargin)
            emissionHandle = @(q, r, study)emissionMixBetaBinomial(q, r, study, theta, lambda1);
            if nargin>4 && ( any(strcmpi('s', varargin)) || any(strcmpi('s', varargin)) ) 
                [obj.Especial, obj.c] = wrapEmissionMatrix(obj.q, obj.r, study, emissionHandle, obj.contrib);
                if nargout>1
                    varargout{1} = obj.Especial;
                end
            else
                [obj.E, obj.c] = wrapEmissionMatrix(obj.q, obj.r, study, emissionHandle, obj.contrib);
            end
            
        end
        
        %% plot
        function fh = plotPkx(obj)
            fh = figure();
            surf(obj.kvect, z.x, z.PoutFull, 'linestyle', 'none');
            view(90, 90)
        end
    end
end