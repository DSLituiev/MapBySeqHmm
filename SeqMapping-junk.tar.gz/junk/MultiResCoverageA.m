function MultiResCoverageA(ChrReads,chr)

% AvSNPperNT = size(ChrMap(chr).x,1)./double(max(ChrMap(chr).x));
xgrid = (1:2^13:single(max(ChrReads(chr).x)))';
dx = bsxfun(@minus,xgrid,single(ChrReads(chr).x'));
% clear xgrid
sigma = 2.^(13:21)';
W = single(bsxfun(@rdivide,abs(dx),permute(sigma, [3,2,1])) < 1);
W = W + 0.5* single(bsxfun(@rdivide, abs(dx), permute(sigma,[3,2,1])) == 1);
% dx2 = bsxfun(@minus,xgrid,double(Data_xrqExNsSt{1,chr}(:,1)')).^2;
% sigma2 = sigma.^2;
% W = exp(-0.5*bsxfun(@rdivide,dx2,permute(sigma2,[3,2,1])));
% % squeeze(sum(sum(W,1),2))
%  W = bsxfun(@rdivide,W,permute(sigma,[3,2,1]))*sqrt(2*pi);
% % squeeze(sum(sum(W,1),2))
clear sigma2 dx
 squeeze(sum(sum(W,1), 2))./sigma
Wr = squeeze(mtimesx(W, single(ChrReads(chr).r)));
%  sum(Wr,1)'
figure
% surf(single(1e-6*Data_xrqExNsSt{1,chr}(:,1)),sigma,Wr','linestyle','none')
pcolor(1e-6*xgrid, sigma, log10(bsxfun(@rdivide,Wr,sum(Wr,1))'))
% surf(1e-6*xgrid, sigma, log10(bsxfun(@rdivide,Wr,sum(Wr,1))'),'linestyle','none')
view(0,90)
set(gca,'yscale','log')
